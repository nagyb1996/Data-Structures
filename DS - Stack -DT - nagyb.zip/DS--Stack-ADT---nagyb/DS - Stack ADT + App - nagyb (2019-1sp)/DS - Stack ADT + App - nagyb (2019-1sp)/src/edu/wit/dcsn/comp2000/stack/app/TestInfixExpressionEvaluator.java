/*
 * Dave Rosenberg
 * Comp 2000 - Data Structures
 * Lab: Stack ADT
 * Spring, 2019
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your learning
 * for this course. You may not use this code for any other assignments, in my course or
 * elsewhere, without explicit permission, in advance, from myself (and the instructor of
 * any other course). Further, you may not post or otherwise share this code with anyone
 * other than current students in my sections of this course. Violation of these usage
 * restrictions will be considered a violation of the Wentworth Institute of Technology
 * Academic Honesty Policy.
 */

package edu.wit.dcsn.comp2000.stack.app ;


import java.io.File ;
import java.io.FileNotFoundException ;
import java.util.Scanner ;


/**
 * Test driver for InfixExpressionEvaluator.
 * <p>
 * Standard: Support for valid expressions containing:
 * <ul>
 * <li>single-digit, unsigned, decimal operands
 * <li>operators: {@code +, -, *, /}
 * <li>parentheses
 * </ul>
 * <br>
 * Optional: Support for valid expressions containing all of the above plus:
 * <ul>
 * <li>multi-digit unsigned decimal operands.
 * </ul>
 * <br>
 * Optional: Support for valid expressions containing all of the above plus:
 * <ul>
 * <li>invalid characters
 * <li>unbalanced parentheses
 * <li>multiple consecutive operators
 * <li>division by zero
 * </ul>
 *
 * @author Dave Rosenberg
 * @version	1.0.0	2019-02-08	initial implementation
 */
public class TestInfixExpressionEvaluator
	{

	/**
	 * prevent instantiation
	 */
	private TestInfixExpressionEvaluator()
		{
		// can't instantiate an InfixExpressionEvaluator
		}	// end constructor


	/**
	 * Driver for the InfixExpressionEvaluator's evaluator()
	 * 
	 * @param args
	 *        -unused-
	 * @throws FileNotFoundException
	 *         if the specified expressions file can't be opened
	 */
	public static void main( String[] args ) throws FileNotFoundException
		{
		// convenience variable
		// uncomment a single line to use that file - the default is for single-digit, valid expressions
		String expressionsFilename =
						"././DS - Stack ADT + App - nagyb (2019-1sp)/DS - Stack ADT + App - nagyb (2019-1sp)/data/Infix Expressions - single-digit, valid -- 2019-02-08 1745.txt" ;
//						"././DS - Stack ADT + App - nagyb (2019-1sp)/DS - Stack ADT + App - nagyb (2019-1sp)/data/Infix Expressions - multi-digit, valid -- 2019-02-08 1745.txt" ;
//						"./data/Infix Expressions - multi-digit, invalid -- 2019-02-08 1745.txt" ;
		
		
		// counters for statistics reporting
		int expressionCount =						0 ;
		int correctResultCount =					0 ;
		
		
		// evaluate all expressions in the data file
		try ( Scanner expressions =					new Scanner( new File( expressionsFilename ) ) )
			{
			while ( expressions.hasNextLine() )
				{
				// get an expression from the file
				String fullExpression =				expressions.nextLine() ;
				
				expressionCount++ ;
				
				// extract the expression and the expected result
				String[] expressionParts =	fullExpression.split( "=" ) ;
				
				String expression =			expressionParts[ 0 ].trim() ;
				
				long expectedResult ;
				boolean expectExpressionIsValid =	true ;
				
				long actualResult ;
				
				try
					{
					expectedResult =				Long.parseLong( expressionParts[ 1 ].trim() ) ;
					}
				catch ( @SuppressWarnings( "unused" ) NumberFormatException e )
					{
					expectedResult =				0 ;
					expectExpressionIsValid =		false ;
					}	// end try
				
				// display what we're evaluating
				System.out.printf( "%n[%,d] expression: %s%n",
				                   expressionCount,
				                   expression ) ;
				if ( expectExpressionIsValid )
					{
					System.out.printf( "\texpected result: %,d%n",
					                   expectedResult ) ;
					}
				else
					{
					System.out.printf( "\texpected result: %s%n",
					                   expressionParts[ 1 ].trim() ) ;
					}	// end if
				
				try
					{
					// evaluate the expression
//					actualResult =				InfixExpressionEvaluator.evaluate( expression );
					actualResult =				InfixExpressionEvaluator.evaluate( expression );
					
					correctResultCount++ ;
					
					System.out.printf( "\tactual result: %,d (%s)%n",
					                   actualResult,
					                   ( actualResult == expectedResult
					                   		? "correct"
					                   		: "incorrect" )
					                   ) ;
					}
				catch ( ArithmeticException e )
    				{
    				if ( e.getMessage().equals( expressionParts[ 1 ].trim() ) )
    					{
    					correctResultCount++ ;
    					}
    				// display the result
					System.out.printf( "\tactual result: %s (%s)%n",
					                   e.getMessage(),
					                   ( e.getMessage().equals( expressionParts[ 1 ].trim() )
    				                   		? "correct"
    				                   		: "incorrect" )
					                   ) ;
    				}	// end try

				}	// end while
			
			}	// end try
		
		
		// display test execution summary
		System.out.printf( "%n%,d of %,d expressions evaluated correctly%n",
		                   correctResultCount,
		                   expressionCount
		                   ) ;

		}	// end main()

	}	// end class TestInfixExpressionEvaluator
