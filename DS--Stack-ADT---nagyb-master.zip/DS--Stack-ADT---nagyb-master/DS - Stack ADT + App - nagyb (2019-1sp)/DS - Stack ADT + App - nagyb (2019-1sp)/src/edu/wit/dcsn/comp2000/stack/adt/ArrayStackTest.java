/*
 * Dave Rosenberg
 * Comp 2000 - Data Structures
 * Lab: Stack ADT
 * Spring, 2019
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your learning
 * for this course. You may not use this code for any other assignments, in my course or
 * elsewhere, without explicit permission, in advance, from myself (and the instructor of
 * any other course). Further, you may not post or otherwise share this code with anyone
 * other than current students in my sections of this course. Violation of these usage
 * restrictions will be considered a violation of the Wentworth Institute of Technology
 * Academic Honesty Policy.
 */

package edu.wit.dcsn.comp2000.stack.adt;

import static org.junit.jupiter.api.Assertions.* ;

import org.junit.jupiter.api.AfterAll ;
import org.junit.jupiter.api.AfterEach ;
import org.junit.jupiter.api.BeforeAll ;
import org.junit.jupiter.api.BeforeEach ;
import org.junit.jupiter.api.DisplayName ;
import org.junit.jupiter.api.Test ;
import org.junit.jupiter.api.TestInfo ;

import java.time.Duration ;
import java.util.Arrays ;
import java.util.EmptyStackException ;

import edu.wit.dcsn.comp2000.stack.adt.ArrayStack ;
import edu.wit.dcsn.comp2000.stack.common.StackInterface ;


/**
 * JUnit tests for the ArrayStack class.  All public and package visible methods are 
 * tested.  These tests require the API for the ArrayStack class implement StackInterface&lt;T&gt;.
 * 
 * @author David M Rosenberg
 * @version 1.0.0 	2018-06-08	initial set of tests<br>
 * @version 1.1.0	2018-06-09	revise structure to use TestInfo instead of certain hard-coded text<br>
 * @version 1.1.1	2018-06-27	enhanced tearDownAfterClass()
 * @version	1.2.0	2018-09-02	add timeouts
 * @version	1.3.0	2019-02-08	add tests of toArray() via toString() to testFullStack() and testStackGrowth()
 */
class ArrayStackTest
	{
	/*
	 * constants copied from ArrayStack.java
	 */
	/* default number of entries in a stack */
	private static final int DEFAULT_CAPACITY =	50 ;
	/* maximum number of entries in a stack */
	private static final int MAX_CAPACITY =		10000 ;
	
	/*
	 * local constants
	 */
	private static final int SMALL_CAPACITY =	13 ;
	private static final int MEDIUM_CAPACITY =	SMALL_CAPACITY + ( SMALL_CAPACITY / 2 ) ;
	private static final int LARGE_CAPACITY =	MAX_CAPACITY / 2 ;
	
	private static final int STACK_1_BASE =		100 ;
	private static final int STACK_2_BASE =		100000 ;

	/*
	 * test constants, counters and labels
	 */
	private static final long TEST_TIME_LIMIT =	10000 ;		// 10 seconds (in milliseconds)
	
	// overall
	private static final String TEST_CLASS_NAME =	"ArrayStack" ;
	
	private static int totalTestsAttempted =	0 ;
	private static int totalTestsSucceeded =	0 ;
	
	// current test group/method
	private int currentTestsAttempted ;
	private int currentTestsSucceeded ;
	

	/**
	 * @throws java.lang.Exception should never happen
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception
		{
		// display start of testing (class)
		System.out.printf( "Starting tests of class %s%n%n",
		                   TEST_CLASS_NAME
		                   ) ;
		
		}	// end setUpBeforeClass()


	/**
	 * @throws java.lang.Exception should never happen
	 */
	@AfterAll
	static void tearDownAfterClass() throws Exception
		{
		// display summary results

		if ( totalTestsAttempted > 0 )
			{
    		System.out.printf( "Successfully completed %,d of %,d tests (%d%%) attempted for class %s%n",
    							totalTestsSucceeded,
    							totalTestsAttempted,
    							( totalTestsSucceeded * 100 ) / totalTestsAttempted,
    							TEST_CLASS_NAME
    							) ;
			}
		else
			{
			System.out.printf( "No tests attempted for class %s%n",
			                    TEST_CLASS_NAME
			                    ) ;
			}
		
		}	// end tearDownAfterClass()


	/**
	 * @param testInfo the current test environment
	 * @throws java.lang.Exception should never happen
	 */
	@BeforeEach
	void setUp( TestInfo testInfo ) throws Exception
		{
		// reset current test counters
		currentTestsAttempted =		0 ;
		currentTestsSucceeded =	0 ;
		
		// display start of testing (method or category/group of operations)
		System.out.printf( "Starting %s tests%n%n",
							testInfo.getDisplayName()
							) ;
		
		}	// end setUp()


	/**
	 * @param testInfo the current test environment
	 * @throws java.lang.Exception should never happen
	 */
	@AfterEach
	void tearDown( TestInfo testInfo ) throws Exception
		{
		// display stats for this test group
		System.out.printf( "%nSuccessfully completed %,d of %,d tests (%d%%) for %s%n%n----------%n%n",
							currentTestsSucceeded,
							currentTestsAttempted,
							( currentTestsSucceeded * 100 ) / currentTestsAttempted,
							testInfo.getDisplayName() ) ;
		
		// accumulate this test group's results
		totalTestsAttempted +=		currentTestsAttempted ;
		totalTestsSucceeded +=		currentTestsSucceeded ;
		}	// end tearDown()


	/**
	 * Test method for instantiating stacks.
	 */
	@Test
	@DisplayName( "Instantiate Stack" )
	void testInstantiateStack()
		{
		assertTimeoutPreemptively( Duration.ofMillis( TEST_TIME_LIMIT ), 
		    () -> {
        		StackInterface<Object> testStack ;
        		
        		int testSize ;
        		
        		boolean sawException ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: DEFAULT_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					DEFAULT_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>() ;
        		
        		assertNotNull( testStack ) ;
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: SMALL_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					SMALL_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		assertNotNull( testStack ) ;
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: LARGE_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					LARGE_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		assertNotNull( testStack ) ;
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: MAX_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					MAX_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		assertNotNull( testStack ) ;
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: over MAX_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					MAX_CAPACITY + 1 ;
        		
        		sawException =				false ;
        		try
        			{
        			testStack =				null ;	// reset the pointer
        			testStack =				new ArrayStack<>( testSize ) ;
        			}
        		catch ( @SuppressWarnings( "unused" ) IllegalStateException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;		// make sure we got the (right) exception
        
        		// if we have an instance, make sure it's not initialized
        		if ( testStack != null )
        			{
        			sawException =			false ;
        			try
        				{
        				testStack.clear() ;
        				}
        			catch ( @SuppressWarnings( "unused" ) SecurityException e )
        				{
        				sawException =		true ;
        				}
        			assertTrue( sawException ) ;	// make sure we got the (right) exception
        			}
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
		
		    } ) ;
		
		}	// end testInstantiateStack()


	/**
	 * Test method for empty stack.
	 */
	@Test
	@DisplayName( "Empty Stack" )
	void testEmptyStack()
		{
		assertTimeoutPreemptively( Duration.ofMillis( TEST_TIME_LIMIT ), 
		    () -> {
        		StackInterface<String> testStack ;
        		
        		int testSize ;
        		
        		boolean sawException ;
        		
        		/* ----- */
        		
        		System.out.println( "Using DEFAULT_CAPACITY stack:" ) ;
        		
        		testSize =					DEFAULT_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>() ;
        		
        		System.out.println( "Testing: isEmpty()" ) ;
        		currentTestsAttempted++ ;
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: clear()" ) ;
        		currentTestsAttempted++ ;
        		
        		testStack.clear() ;
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: peek()" ) ;
        		currentTestsAttempted++ ;
        		
        		sawException =				false ;
        		try
        			{
        			testStack.peek() ;
        			}
        		catch ( @SuppressWarnings( "unused" ) EmptyStackException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;	// make sure we got the (right) exception
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: pop()" ) ;
        		currentTestsAttempted++ ;
        		
        		sawException =				false ;
        		try
        			{
        			testStack.pop() ;
        			}
        		catch ( @SuppressWarnings( "unused" ) EmptyStackException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;	// make sure we got the (right) exception
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		/* ----- */
        		
        		System.out.println( "\nUsing SMALL_CAPACITY stack:" ) ;
        		
        		testSize =					SMALL_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		System.out.println( "Testing: isEmpty()" ) ;
        		currentTestsAttempted++ ;
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: clear()" ) ;
        		currentTestsAttempted++ ;
        		
        		testStack.clear() ;
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: peek()" ) ;
        		currentTestsAttempted++ ;
        		
        		sawException =				false ;
        		try
        			{
        			testStack.peek() ;
        			}
        		catch ( @SuppressWarnings( "unused" ) EmptyStackException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;	// make sure we got the (right) exception
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: pop()" ) ;
        		currentTestsAttempted++ ;
        		
        		sawException =				false ;
        		try
        			{
        			testStack.pop() ;
        			}
        		catch ( @SuppressWarnings( "unused" ) EmptyStackException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;	// make sure we got the (right) exception
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		/* ----- */
        		
        		System.out.println( "\nUsing LARGE_CAPACITY stack:" ) ;
        		
        		testSize =					LARGE_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		System.out.println( "Testing: isEmpty()" ) ;
        		currentTestsAttempted++ ;
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: clear()" ) ;
        		currentTestsAttempted++ ;
        		
        		testStack.clear() ;
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: peek()" ) ;
        		currentTestsAttempted++ ;
        		
        		sawException =				false ;
        		try
        			{
        			testStack.peek() ;
        			}
        		catch ( @SuppressWarnings( "unused" ) EmptyStackException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;	// make sure we got the (right) exception
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: pop()" ) ;
        		currentTestsAttempted++ ;
        		
        		sawException =				false ;
        		try
        			{
        			testStack.pop() ;
        			}
        		catch ( @SuppressWarnings( "unused" ) EmptyStackException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;	// make sure we got the (right) exception
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		/* ----- */
        		
        		System.out.println( "\nUsing MAX_CAPACITY stack:" ) ;
        		
        		testSize =					MAX_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		System.out.println( "Testing: isEmpty()" ) ;
        		currentTestsAttempted++ ;
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: clear()" ) ;
        		currentTestsAttempted++ ;
        		
        		testStack.clear() ;
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: peek()" ) ;
        		currentTestsAttempted++ ;
        		
        		sawException =				false ;
        		try
        			{
        			testStack.peek() ;
        			}
        		catch ( @SuppressWarnings( "unused" ) EmptyStackException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;	// make sure we got the (right) exception
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: pop()" ) ;
        		currentTestsAttempted++ ;
        		
        		sawException =				false ;
        		try
        			{
        			testStack.pop() ;
        			}
        		catch ( @SuppressWarnings( "unused" ) EmptyStackException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;	// make sure we got the (right) exception
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
		
		    } ) ;
		
		}	// end testEmptyStack()


	/**
	 * Test method for full stack.
	 */
	@Test
	@DisplayName( "Full Stack" )
	void testFullStack()
		{
		assertTimeoutPreemptively( Duration.ofMillis( TEST_TIME_LIMIT ), 
		    () -> {
        		StackInterface<Integer> testStack ;
        		
        		int testSize ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: DEFAULT_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					DEFAULT_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>() ;
        		
        		int[] testArray =			new int[ testSize ] ;
        		
        		// fill it
        		for ( int i = 0; i < testSize; i++ )
        			{
        			testStack.push( i );
        			testArray[ testArray.length - 1 - i ] =		i ;
        			
        			assertEquals( i, (int) testStack.peek() ) ;
        			}

        		// verify contents of the stack
        		assertEquals( Arrays.toString( testArray ), testStack.toString() ) ;
        		
        		// empty it
        		for ( int i = testSize - 1; i >= 0; i-- )
        			{
        			assertEquals( i, (int) testStack.peek() ) ;
        			assertEquals( i, (int) testStack.pop() );
        			}
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: SMALL_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					SMALL_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		testArray =					new int[ testSize ] ;
        		
        		// fill it
        		for ( int i = 0; i < testSize; i++ )
        			{
        			testStack.push( i );
        			testArray[ testArray.length - 1 - i ] =		i ;
        			
        			assertEquals( i, (int) testStack.peek() ) ;
        			}

        		// verify contents of the stack
        		assertEquals( Arrays.toString( testArray ), testStack.toString() ) ;
        		
        		// empty it
        		for ( int i = testSize - 1; i >= 0; i-- )
        			{
        			assertEquals( i, (int) testStack.peek() ) ;
        			assertEquals( i, (int) testStack.pop() );
        			}
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: LARGE_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					LARGE_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		testArray =					new int[ testSize ] ;
        		
        		// fill it
        		for ( int i = 0; i < testSize; i++ )
        			{
        			testStack.push( i );
        			testArray[ testArray.length - 1 - i ] =		i ;
        			
        			assertEquals( i, (int) testStack.peek() ) ;
        			}

        		// verify contents of the stack
        		assertEquals( Arrays.toString( testArray ), testStack.toString() ) ;
        		
        		// empty it
        		for ( int i = testSize - 1; i >= 0; i-- )
        			{
        			assertEquals( i, (int) testStack.peek() ) ;
        			assertEquals( i, (int) testStack.pop() );
        			}
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: MAX_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					MAX_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		testArray =					new int[ testSize ] ;
        		
        		// fill it
        		for ( int i = 0; i < testSize; i++ )
        			{
        			testStack.push( i );
        			testArray[ testArray.length - 1 - i ] =		i ;
        			
        			assertEquals( i, (int) testStack.peek() ) ;
        			}

        		// verify contents of the stack
        		assertEquals( Arrays.toString( testArray ), testStack.toString() ) ;
        		
        		// empty it
        		for ( int i = testSize - 1; i >= 0; i-- )
        			{
        			assertEquals( i, (int) testStack.peek() ) ;
        			assertEquals( i, (int) testStack.pop() );
        			}
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
		
		    } ) ;
		
		}	// end testFullStack()


	/**
	 * Test method for full stack.
	 */
	@Test
	@DisplayName( "Stack Growth" )
	void testStackGrowth()
		{
		assertTimeoutPreemptively( Duration.ofMillis( TEST_TIME_LIMIT ), 
		    () -> {
        		StackInterface<Integer> testStack ;
        		
        		int testSize ;
        		
        		boolean sawException ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: DEFAULT_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					DEFAULT_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>() ;
        		
        		int[] testArray =			new int[ LARGE_CAPACITY + 1 ] ;
        		
        		// fill it
        		for ( int i = 0; i <= LARGE_CAPACITY; i++ )
        			{
        			testStack.push( i );
        			testArray[ testArray.length - 1 - i ] =		i ;
        			
        			assertEquals( i, (int) testStack.peek() ) ;
        			}
 
        		// verify contents of the stack
        		assertEquals( Arrays.toString( testArray ), testStack.toString() ) ;
        		
        		// empty it
        		for ( int i = LARGE_CAPACITY; i >= 0; i-- )
        			{
        			assertEquals( i, (int) testStack.peek() ) ;
        			assertEquals( i, (int) testStack.pop() );
        			}
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: SMALL_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					SMALL_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		testArray =					new int[ LARGE_CAPACITY + 1 ] ;
        		
        		// fill it
        		for ( int i = 0; i <= LARGE_CAPACITY; i++ )
        			{
        			testStack.push( i );
        			testArray[ testArray.length - 1 - i ] =		i ;
        			
        			assertEquals( i, (int) testStack.peek() ) ;
        			}
        		
        		assertEquals( Arrays.toString( testArray ), testStack.toString() ) ;
        		
        		// empty it
        		for ( int i = LARGE_CAPACITY; i >= 0; i-- )
        			{
        			assertEquals( i, (int) testStack.peek() ) ;
        			assertEquals( i, (int) testStack.pop() );
        			}
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: LARGE_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					LARGE_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		testArray =					new int[ MAX_CAPACITY ] ;
        		
        		// fill it
        		for ( int i = 0; i < MAX_CAPACITY; i++ )
        			{
        			testStack.push( i );
        			testArray[ testArray.length - 1 - i ] =		i ;
        			
        			assertEquals( i, (int) testStack.peek() ) ;
        			}
        		
        		assertEquals( Arrays.toString( testArray ), testStack.toString() ) ;
        		
        		// empty it
        		for ( int i = MAX_CAPACITY - 1; i >= 0; i-- )
        			{
        			assertEquals( i, (int) testStack.peek() ) ;
        			assertEquals( i, (int) testStack.pop() );
        			}
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: MAX_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					MAX_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		testArray =					new int[ MAX_CAPACITY ] ;
        		
        		// fill it
        		for ( int i = 0; i < testSize; i++ )
        			{
        			testStack.push( i );
        			testArray[ testArray.length - 1 - i ] =		i ;
        			
        			assertEquals( i, (int) testStack.peek() ) ;
        			}
        		
        		assertEquals( Arrays.toString( testArray ), testStack.toString() ) ;
        		
        		// empty it
        		for ( int i = testSize - 1; i >= 0; i-- )
        			{
        			assertEquals( i, (int) testStack.peek() ) ;
        			assertEquals( i, (int) testStack.pop() );
        			}
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: over-fill a LARGE_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					LARGE_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		testArray =					new int[ MAX_CAPACITY ] ;
        		
        		// fill it
        		for ( int i = 0; i < MAX_CAPACITY; i++ )
        			{
        			testStack.push( i );
        			testArray[ testArray.length - 1 - i ] =		i ;
        			
        			assertEquals( i, (int) testStack.peek() ) ;
        			}
        		
        		// try to over-fill it
        		sawException =				false ;
        		try
        			{
        			testStack.push( MAX_CAPACITY ) ;
        			}
        		catch ( @SuppressWarnings( "unused" ) IllegalStateException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;	// make sure we got the (right) exception
        		
        		assertEquals( Arrays.toString( testArray ), testStack.toString() ) ;
        		
        		// empty it
        		for ( int i = MAX_CAPACITY - 1; i >= 0; i-- )
        			{
        			assertEquals( i, (int) testStack.peek() ) ;
        			assertEquals( i, (int) testStack.pop() );
        			}
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		System.out.println( "Testing: over-fill a MAX_CAPACITY stack" ) ;
        		currentTestsAttempted++ ;
        		
        		testSize =					MAX_CAPACITY ;
        		
        		testStack =					null ;	// reset the pointer
        		testStack =					new ArrayStack<>( testSize ) ;
        		
        		testArray =					new int[ MAX_CAPACITY ] ;
        		
        		// fill it
        		for ( int i = 0; i < testSize; i++ )
        			{
        			testStack.push( i );
        			testArray[ testArray.length - 1 - i ] =		i ;
        			
        			assertEquals( i, (int) testStack.peek() ) ;
        			}
        		
        		// try to over-fill it
        		sawException =				false ;
        		try
        			{
        			testStack.push( MAX_CAPACITY ) ;
        			}
        		catch ( @SuppressWarnings( "unused" ) IllegalStateException e )
        			{
        			sawException =			true ;
        			}
        		assertTrue( sawException ) ;	// make sure we got the (right) exception
        		
        		assertEquals( Arrays.toString( testArray ), testStack.toString() ) ;
        		
        		// empty it
        		for ( int i = MAX_CAPACITY - 1; i >= 0; i-- )
        			{
        			assertEquals( i, (int) testStack.peek() ) ;
        			assertEquals( i, (int) testStack.pop() );
        			}
        		
        		assertTrue( testStack.isEmpty() );
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
		
		    } ) ;
		
		}	// end testStackGrowth()


	/**
	 * Test method for multiple stacks.
	 */
	@Test
	@DisplayName( "Multiple Stacks" )
	void testMultipleStacks()
		{
		assertTimeoutPreemptively( Duration.ofMillis( TEST_TIME_LIMIT ), 
		    () -> {
        		StackInterface<Integer> testStack1 ;
        		StackInterface<Integer> testStack2 ;
        		
        		Integer testValue37 = new Integer( 37 ) ;
        		Integer testValue42 = new Integer( 42 ) ;
        		
        		/* ----- */
        		
        		/*
        		 * - instantiate 2 stacks
        		 * - add an item to one stack
        		 * - make sure it contains the item and other is still empty
        		 * - repeat test with opposite stacks
        		 * - repeat test with both stacks simultaneously
        		 * - remove the items and make sure both stacks are empty
        		 */
        		System.out.println( "Testing: multiple stack instances (1)" ) ;
        		currentTestsAttempted++ ;
        		
        		System.out.println( "...instantiate 2 stacks" ) ;
        		testStack1 =				null ;	// reset the pointer
        		testStack1 =				new ArrayStack<>() ;
        		
        		testStack2 =				null ;	// reset the pointer
        		testStack2 =				new ArrayStack<>() ;
        		
        		// add an item to testStack1
        		System.out.println( "...push 1 item onto stack 1" ) ;
        		testStack1.push( testValue42 );
        		
        		System.out.println( "...test for item on stack 1" ) ;
        		assertFalse( testStack1.isEmpty() ) ;
        		assertEquals( testValue42, testStack1.peek() ) ;
        		
        		// testStack2 must still be empty
        		System.out.println( "...test stack 2 for empty" ) ;
        		assertTrue( testStack2.isEmpty() ) ;
        		
        		// we can remove the item from testStack1 and both stacks are now empty
        		System.out.println( "...pop item from stack 1" ) ;
        		assertEquals( testValue42, testStack1.pop() ) ;
        		
        		System.out.println( "...verify both stacks empty" ) ;
        		assertTrue( testStack1.isEmpty() ) ;
        		assertTrue( testStack2.isEmpty() ) ;
        		
        		// add an item to testStack2
        		System.out.println( "...push 1 item onto stack 2" ) ;
        		testStack2.push( testValue37 );
        
        		System.out.println( "...test for item on stack 2" ) ;
        		assertFalse( testStack2.isEmpty() ) ;
        		assertEquals( testValue37, testStack2.peek() ) ;
        
        		// testStack1 must still be empty
        		System.out.println( "...test stack 1 for empty" ) ;
        		assertTrue( testStack1.isEmpty() ) ;
        
        		// we can remove the item from testStack2 and both stacks are now empty
        		System.out.println( "...pop item from stack 2" ) ;
        		assertEquals( testValue37, testStack2.pop() ) ;
        
        		System.out.println( "...verify both stacks empty" ) ;
        		assertTrue( testStack1.isEmpty() ) ;
        		assertTrue( testStack2.isEmpty() ) ;
        
        		// add an item to testStack1
        		System.out.println( "...push 1 item onto each stack" ) ;
        		testStack1.push( testValue42 );
        		testStack2.push( testValue37 );
        
        		System.out.println( "...test for correct items on each stack" ) ;
        		assertFalse( testStack1.isEmpty() ) ;
        		assertEquals( testValue42, testStack1.peek() ) ;
        		assertFalse( testStack2.isEmpty() ) ;
        		assertEquals( testValue37, testStack2.peek() ) ;
        
        		// we can remove the items from each and both stacks are now empty
        		System.out.println( "...pop items from each stack" ) ;
        		assertEquals( testValue42, testStack1.pop() ) ;
        		assertEquals( testValue37, testStack2.pop() ) ;
        
        		System.out.println( "...verify both stacks empty" ) ;
        		assertTrue( testStack1.isEmpty() ) ;
        		assertTrue( testStack2.isEmpty() ) ;
        
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		/*
        		 * - instantiate stack 1
        		 * - add an item to one stack
        		 * - instantiate stack 2
        		 * - make sure stack 1 contains the item and stack 2 is empty
        		 * - remove the item from stack 1 and make sure both stacks are empty
        		 */
        		System.out.println( "Testing: multiple stack instances (2)" ) ;
        		currentTestsAttempted++ ;
        		
        		System.out.println( "...instantiate stack 1" ) ;
        		testStack1 =				null ;	// reset the pointer
        		testStack1 =				new ArrayStack<>() ;
        		
        		// add an item to testStack1
        		System.out.println( "...push 1 item onto stack 1" ) ;
        		testStack1.push( testValue42 );
        		
        		System.out.println( "...test for item on stack 1" ) ;
        		assertFalse( testStack1.isEmpty() ) ;
        		assertEquals( testValue42, testStack1.peek() ) ;
        		
        		System.out.println( "...instantiate stack 2" ) ;
        		testStack2 =				null ;	// reset the pointer
        		testStack2 =				new ArrayStack<>() ;
        		
        		// testStack2 must be empty
        		System.out.println( "...test stack 2 for empty" ) ;
        		assertTrue( testStack2.isEmpty() ) ;
        		
        		// we can remove the item from testStack1 and both stacks are now empty
        		System.out.println( "...pop item from stack 1" ) ;
        		assertEquals( testValue42, testStack1.pop() ) ;
        		
        		System.out.println( "...verify both stacks empty" ) ;
        		assertTrue( testStack1.isEmpty() ) ;
        		assertTrue( testStack2.isEmpty() ) ;
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		/*
        		 * - instantiate 2 stacks
        		 * - add items to each stack
        		 * - make sure each stack contains the correct items
        		 * - remove the items from both stacks and make sure they are both empty
        		 */
        		System.out.println( "Testing: multiple stack instances (3)" ) ;
        		currentTestsAttempted++ ;
        		
        		System.out.println( "...instantiate 2 stacks" ) ;
        		testStack1 =				null ;	// reset the pointer
        		testStack1 =				new ArrayStack<>( SMALL_CAPACITY ) ;
        		
        		testStack2 =				null ;	// reset the pointer
        		testStack2 =				new ArrayStack<>( SMALL_CAPACITY ) ;
        		
        		// add items to testStack1
        		System.out.println( "...push multiple items onto stack 1" ) ;
        		for ( int i = 0; i < MEDIUM_CAPACITY; i++ )
        			{
        			testStack1.push( STACK_1_BASE + i );
        			}
        		
        		// add an items to testStack2
        		System.out.println( "...push multiple items onto stack 2" ) ;
        		for ( int i = 0; i < MEDIUM_CAPACITY; i++ )
        			{
        			testStack2.push( STACK_2_BASE + i );
        			}
        		
        		// remove items from testStack1
        		System.out.println( "...test for items on stack 1" ) ;
        		assertFalse( testStack1.isEmpty() ) ;
        
        		for ( int i = MEDIUM_CAPACITY - 1; i >= 0; i-- )
        			{
        			assertEquals( new Integer( STACK_1_BASE + i ), testStack1.pop() ) ;
        			}
        		
        		assertTrue( testStack1.isEmpty() ) ;
        		
        		// remove items from testStack2
        		System.out.println( "...test for items on stack 2" ) ;
        		assertFalse( testStack2.isEmpty() ) ;
        
        		for ( int i = MEDIUM_CAPACITY - 1; i >= 0; i-- )
        			{
        			assertEquals( new Integer( STACK_2_BASE + i ), testStack2.pop() ) ;
        			}
        
        		assertTrue( testStack2.isEmpty() ) ;
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
        		/*
        		 * - instantiate 2 stacks
        		 * - add items to each stack
        		 * - make sure each stack contains the correct items
        		 * - remove the items from both stacks and make sure they are both empty
        		 */
        		System.out.println( "Testing: multiple stack instances (4)" ) ;
        		currentTestsAttempted++ ;
        		
        		System.out.println( "...instantiate 2 stacks" ) ;
        		testStack1 =				null ;	// reset the pointer
        		testStack1 =				new ArrayStack<>( SMALL_CAPACITY ) ;
        		
        		testStack2 =				null ;	// reset the pointer
        		testStack2 =				new ArrayStack<>( SMALL_CAPACITY ) ;
        		
        		// add items to testStack1
        		System.out.println( "...push multiple items onto stack 1" ) ;
        		for ( int i = 0; i < MEDIUM_CAPACITY; i++ )
        			{
        			testStack1.push( STACK_1_BASE + i );
        			}
        		
        		// add an items to testStack2
        		System.out.println( "...push multiple items onto stack 2" ) ;
        		for ( int i = 0; i < MEDIUM_CAPACITY; i++ )
        			{
        			testStack2.push( STACK_2_BASE + i );
        			}
        		
        		// remove items from testStack2
        		System.out.println( "...test for items on stack 2" ) ;
        		assertFalse( testStack2.isEmpty() ) ;
        
        		for ( int i = MEDIUM_CAPACITY - 1; i >= 0; i-- )
        			{
        			assertEquals( new Integer( STACK_2_BASE + i ), testStack2.pop() ) ;
        			}
        
        		assertTrue( testStack2.isEmpty() ) ;
        		
        		// remove items from testStack1
        		System.out.println( "...test for items on stack 1" ) ;
        		assertFalse( testStack1.isEmpty() ) ;
        
        		for ( int i = MEDIUM_CAPACITY - 1; i >= 0; i-- )
        			{
        			assertEquals( new Integer( STACK_1_BASE + i ), testStack1.pop() ) ;
        			}
        		
        		assertTrue( testStack1.isEmpty() ) ;
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		/* ----- */
        		
		    } ) ;
				
		}	// end testMultipleStacks()

}	// end class ArrayStackTest
