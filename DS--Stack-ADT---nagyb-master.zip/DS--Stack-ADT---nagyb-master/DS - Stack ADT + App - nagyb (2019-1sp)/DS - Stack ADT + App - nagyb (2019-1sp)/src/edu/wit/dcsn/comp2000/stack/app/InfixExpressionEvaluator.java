/*
 * Dave Rosenberg
 * Comp 2000 - Data Structures
 * Lab: Stack ADT
 * Spring, 2019
 * 
 * Use this code as the starting point for your Stack ADT application lab assignment.
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your learning
 * for this course. You may not use this code for any other assignments, in my course or
 * elsewhere, without explicit permission, in advance, from myself (and the instructor of
 * any other course). Further, you may not post or otherwise share this code with anyone
 * other than current students in my sections of this course. Violation of these usage
 * restrictions will be considered a violation of the Wentworth Institute of Technology
 * Academic Honesty Policy.
 */

/*
 * Brody Nagy
 * Comp 2000 - Data Structures
 * Lab: Stack ADT
 * Spring, 2019
 */
package edu.wit.dcsn.comp2000.stack.app;

import static org.junit.Assert.assertEquals;

import edu.wit.dcsn.comp2000.stack.common.StackInterface;

/**
 * A class to evaluate an infix arithmetic expression composed of unsigned,
 * decimal, single-digit operands and a combination of binary operators
 * ({@code +, -, *, /}). Parenthesized (sub-)expressions are supported.
 * <p>
 * Optional: Support for multi-digit unsigned decimal operands.
 * <p>
 * Optional: Invalid characters, unbalanced parentheses, multiple consecutive
 * operators, and division by zero are recognized and handled.
 * 
 * @author Dave Rosenberg
 * @version 1.0.0 2019-02-08 initial implementation
 */
public class InfixExpressionEvaluator {

	/**
	 * prevent instantiation
	 */
	private InfixExpressionEvaluator() {
		// can't instantiate an InfixExpressionEvalueuator
	} // end constructor

	/**
	 * Evaluates an infix arithmetic expression containing unsigned decimal operands
	 * and a combination of operators ({@code +, -, *, /}) including parenthesized
	 * (sub-)expressions. All operations are performed as integers (no fractional
	 * Values).
	 * 
	 * @param expression an infix expression composed of unsigned decimal operands
	 *                   and a combination of operators ({@code +, -, *, /})
	 *                   including parenthesized (sub-)expressions
	 * @return the result of evaluating {@code expression}
	 * @throws ArithmeticException if {@code expression} is syntactically invalid,
	 *                             is null/0-length, or attempts to divide by zero
	 */
	public static long evaluate(String expression) throws ArithmeticException {

		StackInterface<Character> operatorStack = new VectorStack<Character>(); // vector stack to store operators

		StackInterface<Long> valueStack = new VectorStack<Long>(); // vector stack to store operands

		char topOperator; // store top operator
		long operandTwo; // store operand one
		long operandOne; // store operand two
		long result = 0; // initialize result to zero

		int restoreIndex = 0;

		expression = expression.replace("--", "+"); // remove all double minus with plus

		for (int i = 0; i < expression.length(); i++) { // while there are chars to process

			restoreIndex = i; // store index in case it is needed later

			Character nextCharacter = expression.charAt(i); // get next char to process

			Character isDigit = nextCharacter; // variable for switch case

			// if expression contains parenthesis, move to case '(' to evaluate
			// subexpression
			if (expression.contains("(")) {
				isDigit = '(';
				i = restoreIndex; // move index back to continue evaluating after subexpression has been evaluated
			}

			// check if the char is a negative number
			if (i == 0 && isDigit == '-') {
				isDigit = 'F';
			}

			// catch negative numbers next to operators
			if ((isDigit == '*' || isDigit == '/' || isDigit == '-' || isDigit == '+')
					&& expression.charAt(i + 1) == '-') {
				isDigit = 'G';
			}
			// single digit number
			if (Character.isDigit(nextCharacter)) {
				isDigit = 'A';

				if (i + 1 < expression.length()) {
					Character nextAndCharacter = expression.charAt(i + 1);

					// double digit number
					if (Character.isDigit(nextAndCharacter)) {
						isDigit = 'B';

						if (i + 2 < expression.length()) {
							nextAndCharacter = expression.charAt(i + 2);

							// triple digit number
							if (Character.isDigit(nextAndCharacter)) {
								isDigit = 'C';

								if (i + 3 < expression.length()) {
									nextAndCharacter = expression.charAt(i + 3);

									// four digit number
									if (Character.isDigit(nextAndCharacter)) {
										isDigit = 'D';
										if (i + 4 < expression.length()) {
											nextAndCharacter = expression.charAt(i + 4);

											// five digit number
											if (Character.isDigit(nextAndCharacter)) {
												isDigit = 'E';

											}
										}
									}
								}
							}
						}
					}
				}
			}

			// switch on isDigit value
			switch (isDigit) {
			// single digit number
			case 'A':
				// push single digit to stack
				valueStack.push((long) Character.getNumericValue(nextCharacter));
				break;
			// double digit number
			case 'B':
				// push two digits to stack
				String twoDigit = "" + nextCharacter + expression.charAt(i + 1); // build string
				long twoDigitLong = Long.parseLong(twoDigit); // parse long value
				i++; // increment i
				valueStack.push(twoDigitLong); // push to operand stack
				break;
			// triple digit number
			case 'C':
				// push three digits to stack
				String threeDigit = "" + nextCharacter + expression.charAt(i + 1) + expression.charAt(i + 2);
				long threeDigitLong = Long.parseLong(threeDigit);
				i += 2;
				valueStack.push(threeDigitLong);
				break;
			// four digit number
			case 'D':

				String fourDigit = "" + nextCharacter + expression.charAt(i + 1) + expression.charAt(i + 2)
						+ expression.charAt(i + 3);
				long fourDigitLong = Long.parseLong(fourDigit);
				i += 3;
				valueStack.push(fourDigitLong);
				break;

			case 'E':

				String fiveDigit = "" + nextCharacter + expression.charAt(i + 1) + expression.charAt(i + 2)
						+ expression.charAt(i + 3) + expression.charAt(i + 4);
				long fiveDigitLong = Long.parseLong(fiveDigit);
				i += 4;
				valueStack.push(fiveDigitLong);
				break;

			// Leading negative number
			case 'F':
				// push negative number to value stack
				String negative = "" + nextCharacter + expression.charAt(i + 1);
				long negativeNum = Long.parseLong(negative);
				i++;
				valueStack.push(negativeNum);
				break;

			// Negative number and operator
			case 'G':
				String alsoNegative = "" + expression.charAt(i + 1) + expression.charAt(i + 2);
				if (i + 2 == expression.length()) {
					i = 0;
				} else {
					i += 2;
				}
				long alsoNegativeNum = Long.parseLong(alsoNegative);
				valueStack.push(alsoNegativeNum);
				operatorStack.push(nextCharacter);
				break;

			// if char is an operator
			case '+':
			case '-':
			case '*':
			case '/':
				// while operator stack is not empty and the precedence of the operator is less
				// than the precedence of the next operator in the stack.
				while (!operatorStack.isEmpty()
						&& (getPrecedence(nextCharacter) <= getPrecedence(operatorStack.peek()))) {
					// Execute operator at top of operatorStack
					topOperator = operatorStack.pop();
					operandTwo = valueStack.pop();
					operandOne = valueStack.pop();
					// addition
					if (topOperator == '+') {
						result = operandOne + operandTwo;
					}
					// subtraction
					else if (topOperator == '-') {
						result = operandOne - operandTwo;

					}
					// multiplication
					else if (topOperator == '*') {
						result = operandOne * operandTwo;
					}
					// division
					else if (topOperator == '/') {
						// check if next operator is also division, if it is, switch the operands to
						// ensure correct order of execution
						if (!operatorStack.isEmpty() && operatorStack.peek() == '/') {
							long gottaSwitchEm = valueStack.pop();
							valueStack.push(operandTwo);
							result = gottaSwitchEm / operandOne;
						}
						// else do normal division
						else {
							result = operandOne / operandTwo;
						}
					}
					// push result
					valueStack.push(result);

				}
				// if no operation occurred, push it back to the operator stack
				operatorStack.push(nextCharacter);
				break;

			// if expression contains parenthesis
			case '(':
				// store index for later
				i = restoreIndex;

				// get index of opening parenthesis
				int storeIndex = expression.indexOf('(');

				// store result of parenEvaluator in new string
				String recieved = parenEvaluator(expression, storeIndex);

				// get long value of string
				long answer = evaluate(recieved);

				// return answer to main;
				return answer;

			default:
				break;
			}
		}

		// while the operator stack is not empty
		while (!operatorStack.isEmpty()) {
			// retrieve the top operator and top two operands
			topOperator = operatorStack.pop();
			operandTwo = valueStack.pop();
			operandOne = valueStack.pop();
			// flag is an integer used to return an operand in the case of multi-division
			int flag = 0;

			// perform addition
			if (topOperator == '+') {
				result = operandOne + operandTwo;
			}
			// perform subtraction
			else if (topOperator == '-') {
				result = operandOne - operandTwo;
			}
			// perform multiplication
			else if (topOperator == '*') {
				result = operandOne * operandTwo;
			}
			// perform division
			else if (topOperator == '/') {
				// check for multi division
				if (!operatorStack.isEmpty() && operatorStack.peek() == '/') {
					long gottaSwitchEm = valueStack.pop(); // get next value in operand stack
					result = gottaSwitchEm / operandOne;
					flag = 1; // set flag to 1
				}
				// perform division normally
				else {
					result = operandOne / operandTwo;
				}
			}
			// push value to stack
			valueStack.push(result);
			// push operand to stack if flag is 1 from multi-division
			if (flag == 1) {
				valueStack.push(operandTwo);
			}
		}

		// System.out.println(valueStack.peek());

		return valueStack.peek();

	}

	/**
	 * Assigns an integer value to an algebraic operator Returns integer value
	 * 
	 * @param operator
	 * @return
	 */
	public static int getPrecedence(char operator) {
		// integer to store precedence value
		int precedence = 0;
		// addition and subtraction both have a precedence of zero
		if ((operator == '+') || (operator == '-')) {
			precedence = 0;
		}
		// multiplication and division both have a precedence of one
		else if ((operator == '*') || (operator == '/')) {
			precedence = 1;
		}
		// parenthesis precedence is two
		else if ((operator == ')') || (operator == '(')) {
			precedence = 2;
		}
		// return precedence
		return precedence;
	}

	/**
	 * parenEvaluator will evaluate expression inside parenthesis, calls itself
	 * recursively for nested parenthesis
	 * 
	 * @param expression
	 * @param i
	 * @return
	 */
	public static String parenEvaluator(String expression, int i) {

		int j = i + 1;
		char[] subExpression = new char[expression.length()];

		// while the char is not a closing parenthesis
		while (expression.charAt(j) != ')') {
			// if there is another opening parenthesis, store index and call
			// parenEvaluate recursively
			if (expression.charAt(j) == '(') {
				expression = parenEvaluator(expression, j);
			}
			// else add expression to char array
			else {
				subExpression[j] = expression.charAt(j);
				j++;
			}
		}

		// convert char array to string
		String subExpressionString = new String(subExpression);
		// trim white space from expression string
		subExpressionString = subExpressionString.trim();
		// get length of subExpression string
		int length = subExpressionString.length();
		// answer is the result of evaluating subexpression string
		long subAnswer = evaluate(subExpressionString);
		// use string builder to recreate the original, unevaluated subexpression with
		// parenthesis
		StringBuilder appendedSubExpression = new StringBuilder(subExpressionString);
		appendedSubExpression.insert(0, '(');
		appendedSubExpression.insert(length + 1, ')');
		// convert string-builder to string
		String appendedSubExpressionString = new String(appendedSubExpression);
		// replace original, unevaluated subexpression in expression with evaluated
		// subexpression
		String answerExpression = expression.replace(appendedSubExpressionString, Long.toString(subAnswer));

		return answerExpression;
	}

	/**
	 * test driver
	 * 
	 * @param args -unused-
	 */
	public static void main(String[] args) {

		// 2 test for parenEvaluate
		// base case

		parenEvaluatorTest();

		// precedence tests
		//

		precedenceTest();

	} // end main()

	/**
	 * test that parenEvaluator will return a string with the parenthesis processed,
	 * if the string is a single digit with nested parenthesis, it will return the
	 * digit, if it is an expression with multiple sets of parenthesis, it will
	 * create a string with the subexpression contained in the inner set of
	 * parenthesis evaluated, which is then given to evaluate() for processing.
	 */
	private static void parenEvaluatorTest() {

		// single digit in nested parenthesis
		String test = "(((((((((5)))))))))";

		int index = test.indexOf('(');

		// call parenEvaluator
		String answer = (parenEvaluator(test, index));

		// expect nested digit
		String expectedAnswer = "5";

		// assert parenEvaluator returned nested digit
		assertEquals(answer, expectedAnswer);

		// nested expressions
		String testMore = "(5+6)*((5+1)*(2+3))";

		index = testMore.indexOf('(');

		// call parenEvaluator
		answer = (parenEvaluator(testMore, index));

		// expect subexpression to be processed and replaced
		expectedAnswer = "11*((5+1)*(2+3))";

		// assert parenEvaluator returned semi-processed expression
		assertEquals(answer, expectedAnswer);

		index = answer.indexOf('(');

		// call parenEvaluator
		answer = (parenEvaluator(answer, index));

		// expect parenEvaluator to return semi-processed expression
		expectedAnswer = "11*30";

		// assert parenEvaluator returned semi-processed expression
		assertEquals(answer, expectedAnswer);

	}

	/**
	 * test that getPrecedence returns the expected int value for operators
	 */
	private static void precedenceTest() {

		// char[] of operators to test
		char[] operators = { '+', '-', '*', '/', '(', ')' };
		// expected precedence values for each operator
		int[] expected = { 0, 0, 1, 1, 2, 2 };
		// int to store return of getPrecedence
		int actual;

		// Assert that the return of getPrecedence for each char is equal to the
		// expected value
		for (int i = 0; i < expected.length; i++) {
			actual = getPrecedence(operators[i]);
			assertEquals(actual, expected[i]);
		}

	}

} // end class InfixExpressionEvaluator
