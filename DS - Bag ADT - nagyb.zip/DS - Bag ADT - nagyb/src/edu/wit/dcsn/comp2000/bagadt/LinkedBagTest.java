/*
 * David M Rosenberg
 * Comp 2000 - Data Structures
 * Lab: Bag ADT
 * Spring, 2019
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your learning
 * for this course. You may not use this code for any other assignments, in my course or
 * elsewhere, without explicit permission, in advance, from myself (and the instructor of
 * any other course). Further, you may not post or otherwise share this code with anyone
 * other than current students in my sections of this course. Violation of these usage
 * restrictions will be considered a violation of the Wentworth Institute of Technology
 * Academic Honesty Policy.
 */


package edu.wit.dcsn.comp2000.bagadt;

import static org.junit.jupiter.api.Assertions.assertEquals ;
import static org.junit.jupiter.api.Assertions.assertFalse ;
import static org.junit.jupiter.api.Assertions.assertNotNull ;
import static org.junit.jupiter.api.Assertions.assertNull ;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively ;
import static org.junit.jupiter.api.Assertions.assertTrue ;

import org.junit.jupiter.api.AfterAll ;
import org.junit.jupiter.api.AfterEach ;
import org.junit.jupiter.api.BeforeAll ;
import org.junit.jupiter.api.BeforeEach ;
import org.junit.jupiter.api.DisplayName ;
import org.junit.jupiter.api.Test ;
import org.junit.jupiter.api.TestInfo ;

import static java.time.Duration.ofMillis ;


/**
 * JUnit tests for the LinkedBag class.  All public and package visible methods are 
 * tested.  These tests require the API for the LinkedBag class implement BagInterface&lt;T>.
 * 
 * @author  David M Rosenberg
 * @version 1.0.0	2018-05-25	initial set of tests<br>
 * @version 1.1.0	2018-06-09	revise structure to use TestInfo instead of certain hard-coded text
 * @version	1.2.0	2018-09-02	add timeouts
 * @version	1.3.0	2019-01-14	more implementation
 */
class LinkedBagTest
	{
	/*
	 * constants copied from LinkedBag.java
	 */
	// none
	
	/*
	 * local constants
	 */
	// none

	/*
	 * test constants, counters and labels
	 */
	static final long TEST_TIME_LIMIT =			10000 ;		// 10 seconds (in milliseconds)
	
	// overall
	static final String TEST_CLASS_NAME =		"LinkedBag" ;
	
	static int totalTestsAttempted =			0 ;
	static int totalTestsSucceeded =			0 ;
	
	// current test group/method
	int currentTestsAttempted ;
	int currentTestsSucceeded ;
	

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception
		{
		// display start of testing (class)
		System.out.printf( "Starting tests of class %s%n%n",
		                   TEST_CLASS_NAME
		                   ) ;
		
		}	// end setUpBeforeClass()


	/**
	 * @throws java.lang.Exception
	 */
	@AfterAll
	static void tearDownAfterClass() throws Exception
		{
		// display summary results

		if ( totalTestsAttempted > 0 )
			{
    		System.out.printf( "Successfully completed %,d of %,d tests (%d%%) attempted for class %s%n",
    							totalTestsSucceeded,
    							totalTestsAttempted,
    							( totalTestsSucceeded * 100 ) / totalTestsAttempted,
    							TEST_CLASS_NAME
    							) ;
			}
		else
			{
			System.out.printf( "No tests attempted for class %s%n",
			                    TEST_CLASS_NAME
			                    ) ;
			}
		
		}	// end tearDownAfterClass()


	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp( TestInfo testInfo ) throws Exception
		{
		// reset current test counters
		currentTestsAttempted =		0 ;
		currentTestsSucceeded =	0 ;
		
		// display start of testing (method or category/group of operations)
		System.out.printf( "Starting %s tests%n%n",
							testInfo.getDisplayName()
							) ;
		
		}	// end setUp()


	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown( TestInfo testInfo ) throws Exception
		{
		// display stats for this test group
		System.out.printf( "%nSuccessfully completed %,d of %,d tests (%d%%) for %s%n%n----------%n%n",
							currentTestsSucceeded,
							currentTestsAttempted,
							( currentTestsSucceeded * 100 ) / currentTestsAttempted,
							testInfo.getDisplayName() ) ;
		
		// accumulate this test group's results
		totalTestsAttempted +=		currentTestsAttempted ;
		totalTestsSucceeded +=		currentTestsSucceeded ;
		}	// end tearDown()


	/**
	 * Test method for instantiating stacks.
	 */
	@Test
	@DisplayName( "Instantiate Bag" )
	void testInstantiateBag()
		{
		assertTimeoutPreemptively( ofMillis( TEST_TIME_LIMIT ), 
		    () -> {
        		BagInterface<String> testBagOfStrings ;
        		BagInterface<Integer> testBagOfIntegers ;
        
        		Object[] testArrayOfStrings ;
        		Object[] testArrayOfIntegers ;
        		
        		/* ----- */
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: constructor" ) ;
        		
        		testBagOfStrings =			null ;	// reset the pointer
        		testBagOfStrings =			new LinkedBag<>() ;
        		
        		System.out.println( "...new Bag of Strings" ) ;
        		assertNotNull( testBagOfStrings ) ;
        		System.out.println( "...is empty" ) ;
        		assertTrue( testBagOfStrings.isEmpty() );
        		
        		testArrayOfStrings =		null ;	// reset the pointer
        		System.out.println( "...to array" ) ;
        		assertNotNull( testArrayOfStrings = testBagOfStrings.toArray() ) ;
        		System.out.println( "...array has 0 elements" ) ;
        		assertEquals(  0, testArrayOfStrings.length ) ;
        		
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
		    } ) ;
		
		}	// end testInstantiateBag()


	/**
	 * Test method for empty bag.
	 */
	@Test
	@DisplayName( "Empty Bag" )
	void testEmptyBag()
		{
		assertTimeoutPreemptively( ofMillis( TEST_TIME_LIMIT ), 
		    () -> {
        		BagInterface<String> testBag = new LinkedBag<>() ;
        		String test1stString = "1st" ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: isEmpty()" ) ;
        		assertTrue( testBag.isEmpty() );
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: getCurrentSize() == 0" ) ;
        		assertEquals( 0, testBag.getCurrentSize() );
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: getFrequencyOf( \"" + test1stString + "\" )" ) ;
        		assertEquals( 0, testBag.getFrequencyOf( test1stString ) );
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: remove()" ) ;
        		assertEquals( null, testBag.remove() );
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: remove( \"" + test1stString + "\" )" ) ;
        		assertFalse( testBag.remove( test1stString ) );
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: clear()" ) ;
        		testBag.clear() ;
        		assertTrue( testBag.isEmpty() );
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: toArray()" ) ;
        		Object[] testBagArray = testBag.toArray() ;
        		
        		System.out.println( "- non-null reference" ) ;
        		assertNotNull( testBagArray ) ;
        		
        		System.out.println( "- length == 0" ) ;
        		assertEquals( 0, testBagArray.length ) ;
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
		    } ) ;
		
		}	// end testEmptyBag()


	/**
	 * Test method for a bag with one item.
	 */
	@Test
	@DisplayName( "Bag with 1 item" )
	void testOneItemBag()
		{
		assertTimeoutPreemptively( ofMillis( TEST_TIME_LIMIT ), 
		    () -> {
        		BagInterface<String> testBag = new LinkedBag<>() ;
        		String test1stString = "1st" ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: add( \"" + test1stString + "\" )" ) ;
        		assertTrue( testBag.add( test1stString ) ) ;
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: getFrequencyOf( \"" + test1stString + "\" )" ) ;
        		assertEquals( 1, testBag.getFrequencyOf( test1stString ) );
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: remove()" ) ;
        		assertEquals( test1stString, testBag.remove() );
        		assertNull( testBag.remove() ) ;
        		assertTrue( testBag.isEmpty() ) ;
        		assertEquals( 0, testBag.getCurrentSize() ) ;
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: remove( \"" + test1stString + "\" )" ) ;
        		assertTrue( testBag.add( test1stString ) ) ;		// re-add the item
        		assertTrue( testBag.remove( test1stString ) );
        		assertFalse( testBag.remove( test1stString ) ) ;
        		assertTrue( testBag.isEmpty() ) ;
        		assertEquals( 0, testBag.getCurrentSize() ) ;
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: isEmpty()" ) ;
        		assertTrue( testBag.isEmpty() );
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.println( "Testing: getCurrentSize() == 0" ) ;
        		assertEquals( 0, testBag.getCurrentSize() );
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
		    } ) ;
		
		}	// end testOneItemBag()


	/**
	 * Test method for a bag with multiple items.
	 */
	@Test
	@DisplayName( "Bag with multiple items" )
	void testMultiItemBag()
		{
		assertTimeoutPreemptively( ofMillis( TEST_TIME_LIMIT ), 
		    () -> {
        		BagInterface<Integer> testBag = new LinkedBag<>() ;
        		Integer[] testValues = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;
        		
        		currentTestsAttempted++ ;
        		System.out.print( "Testing: add()ing:" ) ;
        		for ( int i = 0; i < testValues.length; i++ )	// add the test values to the bag
        			{
        			System.out.print( " " + testValues[ i ] ) ;
        			assertTrue( testBag.add( testValues[ i ] ) ) ;
        			
        			assertFalse( testBag.isEmpty() );
        			assertEquals( i + 1, testBag.getCurrentSize() );
        			assertTrue( testBag.contains( testValues[ i ] ) ) ;
        			}
        		System.out.println() ;
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		System.out.print( "Testing: remove()ing:" ) ;
//        		testBag = new LinkedBag<>() ;
        		for ( int i = 0; i < testValues.length; i++ )	// verify that every test item is in the bag
        			{
        			System.out.print( " " + testValues[ i ] ) ;
        			assertTrue( testBag.remove( testValues[ i ] ) ) ;
        			assertEquals( testValues.length - i - 1, testBag.getCurrentSize() ) ;
        			}
        		assertTrue( testBag.isEmpty() ) ;
        		System.out.println() ;
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
        		
        		currentTestsAttempted++ ;
        		testBag = new LinkedBag<>() ;
        		System.out.println( "Testing: getFrequencyOf():" ) ;
        		for ( int i = 0; i < testValues.length; i++ )	// add the test values to the bag
        			{
        			testBag.add( testValues[ i ] ) ;
        			}
        		
//        		// count the number of times each element in the bag occurs and verify 
//        		// against the number in the array
//        		while ( ! testBag.isEmpty() )
//        			{
//        			
//        			}
//        		assertEquals( 1, testBag.getFrequencyOf( test1stString ) );
        		currentTestsSucceeded++ ;
        		System.out.println( "...passed" ) ;
		
//        		currentTestsAttempted++ ;
//        		testBag = new LinkedBag<>() ;
//        		System.out.println( "Testing: getCurrentSize() == 0" ) ;
//        		assertEquals( 0, testBag.getCurrentSize() );
//        		currentSuccessfulTests++ ;
//        		System.out.println( "...passed" ) ;
		
		    } ) ;	// end assertTimeoutPreemptively()
		
		}	// end testMultiItemBag()
	
	
	/**
	 * Count the number of occurrences of a value in an array 
	 * @param values the collection of values
	 * @param testValue the test value
	 * @return the number of time testValue occurred in values
	 */
	private static int countOccurrences( Integer[] values, int testValue )
    	{
    	int occurrences = 0 ;
    	for ( int i = 0; i < values.length; i++ )
    		{
    		if( values[ i ] == testValue )
    			{
    			occurrences++ ;
    			}
    		}
    	
    	return occurrences ;
    	}	// end countOccurrences

	}	// end class LinkedBagTest
