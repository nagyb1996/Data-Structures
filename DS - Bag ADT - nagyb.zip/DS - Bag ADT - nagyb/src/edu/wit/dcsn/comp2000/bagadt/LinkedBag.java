/*
 * Brody Nagy
 * Comp 2000 - Data Structures
 * Lab: Bag ADT
 * Spring, 2019
 * Due 1/29/2019
 */
/**
 * 
 */
package edu.wit.dcsn.comp2000.bagadt;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;

/**
 * This program is an implementation of an ADT Bag.
 * The data is stored unordered and allows for duplicates.
 * It uses the private inner-class Node to provide linked-list functionality.
 * Functionality is tested by a series of static private methods called from main().
 * @author Brody Nagy
 * @param <T> The class of items the Bag will hold.
 */
public class LinkedBag <T> implements BagInterface<T> {

	private Node firstNode; 		//references the first node in the chain
	private int numberOfEntries; 	//number of nodes

	public LinkedBag() {						
		numberOfEntries = 0;		//Initially, has 0 number of entries,
		firstNode = null;			//and firstNode is null
	}	// end no-arg constructor



	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#add(java.lang.Object)
	 */
	@Override
	public boolean add( T newEntry ) {
		boolean result = false;			
		if(newEntry == null) {					    //if newEntry is null, return result (false)
			return result;
		}

		Node newNode = new Node(newEntry);			//create new Node from given entry
		newNode.setNextNode(firstNode); 			//make new node reference rest of the chain

		firstNode = newNode; 						// new node is now at the head of the chain

		result = true;
		numberOfEntries = this.getCurrentSize(); 	//update numberOfEntries
		return result;
		//no max size, but OutOfMemoryError possible
	}	// end add()


	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#clear()
	 */
	@Override
	public void clear() {

		firstNode = null;			//remove link to rest of chain
		
		numberOfEntries = 0;		//let garbage collection do the rest
		
		this.getCurrentSize();		//update current size
		
	}	// end clear()


	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#contains(java.lang.Object)
	 */
	@Override
	public boolean contains( T anEntry ) {	
		boolean found = false;			
		if(anEntry == null) {					    //if newEntry is null, return result (false)
			return found;
		}
		Node currentNode = firstNode;

		while (!found && (currentNode != null)) { 			//iterate through bag until the final entry
			if (anEntry.equals(currentNode.getData())) { 	//check if entry exists 
				found = true;								//update found to true
			}
			else {
				currentNode = currentNode.getNextNode(); 	//move to next node
			}
		} // end while

		return found;

	}	// end contains()


	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#difference(edu.wit.dcsn.comp2000.bagadt.BagInterface)
	 */
	@Override
	public BagInterface<T> difference( BagInterface<T> anotherBag ) {
		LinkedBag<T> dBag = new LinkedBag<T>(); 						

		Node currentNode = firstNode; 									


		while (currentNode != null) { 								    
			if (anotherBag.contains(currentNode.getData())) {           //if node is contained in anotherBag, 
				currentNode = currentNode.getNextNode();				//move to next node
			}
			else {
				dBag.add(currentNode.getData()); 						//if data is not contained in another bag, 
				currentNode = currentNode.getNextNode();				//add it to dBag
			}
		} // end while

		return dBag;

	}	// end difference()


	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#getCurrentSize()
	 */
	@Override
	public int getCurrentSize() {
		Node currentNode = firstNode; 				
		int size = 0;								 //Initial size 0
		
		if(currentNode == null) {
			return size;
		}

		while (currentNode != null) { 				 
			size++; 								 //increment size, 
			currentNode = currentNode.getNextNode(); //and move to next node
		} // end while

		return  size;
	}	// end getCurrentSize()


	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#getFrequencyOf(java.lang.Object)
	 */
	@Override
	public int getFrequencyOf( T anEntry ) {
		int frequency = 0; 									//initial frequency of zero
		Node currentNode = firstNode; 				
		while (currentNode != null) { 						
			if (anEntry.equals(currentNode.getData())) {	//if provided entry equal data of current node
				frequency++;								//increment frequency
			}
			currentNode = currentNode.getNextNode();		
		} // end while

		return frequency;

	}	// end getFrequencyOf()


	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#intersection(edu.wit.dcsn.comp2000.bagadt.BagInterface)
	 */
	@Override
	public BagInterface<T> intersection( BagInterface<T> anotherBag ) {
		BagInterface<T> another = anotherBag; 				//make copy of anotherBag to avoid mutation errors.
		LinkedBag<T> iBag = new LinkedBag<T>(); 			

		Node currentNode = firstNode; 						

		while (currentNode != null) {					    
			if (another.contains(currentNode.getData())) {  //if another bag contains current node data
				iBag.add(currentNode.getData());			//add the node data to iBag
				another.remove(currentNode.getData()); 		//remove node from another to avoid duplicates
				currentNode = currentNode.getNextNode();	
			}
			else {											
				currentNode = currentNode.getNextNode();
			}
		} // end while


		return iBag;

	}	// end intersection()


	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#isEmpty()
	 */
	@Override
	public boolean isEmpty() {
		boolean result = false;

		if (getCurrentSize() == 0) {	//if current size is zero return true
			result = true;
		}

		return result;					//return false if current size is zero
	}	// end isEmpty()


	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#remove()
	 */
	@Override
	public T remove() {
		T result = null;

		if (firstNode != null) {
			result = firstNode.getData();		//store data from first node
			firstNode = firstNode.next; 		//replace first node from chain with next node
			numberOfEntries = getCurrentSize();	//update numberOfEntries
		} // end if
		return result;							//return data from removed result or null if no first node
	}	// end no-arg remove()


	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#remove(java.lang.Object)
	 */
	@Override
	public boolean remove( T anEntry ) {
		boolean result = false;			
		if(anEntry == null) {					    //if newEntry is null, return result (false)
			return result;
		}
		Node nodeN = getReferenceTo(anEntry);	//locate referenced node if exists

		if (nodeN != null) {
			nodeN.setData(firstNode.getData()); // replace located entry with entry in first node
			remove(); 							// remove first node
			result = true;
		} // end if
		return result;
	}	// end 1-arg remove()

	/**
	 * given an entry, finds the reference to node containing entry if exists, if not return null
	 * @param anEntry
	 * @return reference to node containing entry if exists, if not return null
	 */
	private Node getReferenceTo(T anEntry) {
		boolean found = false;
		Node currentNode = firstNode;

		while (!found && (currentNode != null)) {			//while found is false and current node is not null,
			if (anEntry.equals(currentNode.getData())) {	//if supplied entry equals current node data
				found = true;								
			}
			else {
				currentNode = currentNode.getNextNode();	//else get next node
			}
		} // end while

		if (found) {										//if found
			return currentNode;								//return current node
		}
		else {
			return null;									//else return null
		}
	} // end getReferenceTo


	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#toArray()
	 */
	@Override
	public T[] toArray() {
		// the cast is safe because the new array contains null entries
		@SuppressWarnings("unchecked")				   // suppress unchecked cast warnings 
		T[] result = (T[])new Object[numberOfEntries]; // perform unchecked cast
		int index = 0;									

		Node currentNode = firstNode;
		while (currentNode != null) {					
			result[index] = currentNode.getData();		//add data from currentNode to result array
			index++;
			currentNode = currentNode.getNextNode();
		} // end while

		return result;

	}	// end toArray()


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		Node currentNode = firstNode;
		String result = "";
		while (currentNode != null) {
			result += currentNode.getData().toString() + ", ";		//convert node data to string, add to result string
			currentNode = currentNode.getNextNode();
		} // end while

		return result;

	}	// end toString()

	/* (non-Javadoc)
	 * @see edu.wit.dcsn.comp2000.bagadt.BagInterface#union(edu.wit.dcsn.comp2000.bagadt.BagInterface)
	 */

	@Override
	public BagInterface<T> union( BagInterface<T> anotherBag ) {
		LinkedBag<T> uBag = (LinkedBag<T>) anotherBag; //set equal uBag to anotherBag
		Node currentNode = firstNode;

		while (currentNode != null) {
			uBag.add(currentNode.getData());		   //add all data from this to uBag
			currentNode = currentNode.getNextNode();   
		} // end while

		return uBag;

	}	// end union()

	// end of LinkedBag methods


	/**
	 * Inner class Node provides all linked-list functionality
	 */
	private class Node {
		/*
		 * instance variables
		 */
		private T		data ;	// Entry in bag
		private Node	next ;	// Link to next node


		/**
		 * Sets up a node given supplied data; next pointer is set to null.
		 * 
		 * @param dataPortion the information this node holds
		 */
		private Node( T dataPortion ) {
			this( dataPortion, null ) ;
		}	// end 1-arg constructor


		/**
		 * Sets up a node given supplied data and next pointer.
		 * 
		 * @param dataPortion the information this node holds
		 * @param nextNode reference to the next node in the linked list 
		 */
		private Node( T dataPortion, Node nextNode ) {
			data = dataPortion ;
			next = nextNode ;
		}	// end 2-arg constructor


		/**
		 * 
		 * @return a reference to the data stored in this node
		 */
		private T getData() {
			return data ;

		}	// end getData()


		/**
		 * 
		 * @param newData
		 */
		private void setData( T newData ) {
			data = newData ;
		}	// end setData()


		/**
		 * 
		 * @return
		 */
		private Node getNextNode() {
			return next ;
		}	// end getNextNode()


		/**
		 * 
		 * @param nextNode
		 */
		private void setNextNode( Node nextNode ) {
			next = nextNode ;
		} // end setNextNode()

	}	// end inner class Node


	/**
	 * test driver for LinkedBag
	 * 
	 * @param args -unused-
	 */
	public static void main( String[] args ) {

		//add tests
		addNullTester(); 
		addToEmptyTester(); 
		addToPopulatedTester(); 

		//clear tests
		clearPopulatedTester(); 
		clearUnpopulatedTester(); 

		//contains
		containsEmptyTester(); 
		containsExistingTester(); 
		containsNonexistingTester(); 

		//difference
		differenceEmptyTester(); 
		differenceIdenticalTester(); 
		differenceUniqueTester(); 

		//getCurrentSize
		getCurrentSizeEmptyTester(); 
		getCurrentSizePopulatedTester(); 

		//getFrequencyOf
		getFrequencyOfNonexistant(); 
		getFrequencyOfExistant(); 
		getFrequencyOfEmpty(); 

		//intersection
		intersectionEmptyTester(); 
		intersectionIdenticalTester(); 
		intersectionUniqueTester(); 

		//isEmpty
		isEmptyEmptyTester();
		isEmptyPopulatedTester();

		//remove tests
		removeEmptyTester();
		removePopulatedTester();

		//remove(T an Entry) tests ALSO tests getReferenceTo
		removeTEmptyTester();
		removeTNonexistentTester();
		removeTExistentTester();

		//toArray
		toArrayEmptyTester();
		toArrayPopulatedTester();

		//toString tests
		toStringTester(); 
		toStringTesterEmpty(); 

		//union
		unionEmptyTester(); 
		unionIdenticalTester(); 
		unionUniqueTester(); 
		unionUniqueTester2();

		System.out.println("All Tests Passed");


	}	// end main()



	/**
	 * tests that adding null to a bag returns false
	 */
	private static void addNullTester()	{

		BagInterface<Object> testBag = new LinkedBag<>() ;
		Object testValue = null;							//null to add

		assertFalse( testBag.add(testValue) ) ;				//check add returns false
		assertTrue( testBag.isEmpty() );					//check isEmpty returns true

	}

	/**
	 * tests that adding int to empty int bag returns true
	 */
	private static void addToEmptyTester() {

		BagInterface<Integer> testBag = new LinkedBag<>() ;
		Integer testInt = new Integer(45);					//int to add

		assertTrue( testBag.add(testInt) ) ;				//assert adding int returns true
		assertFalse( testBag.isEmpty() );					//assert isEmpty returns false
		assertEquals( 1, testBag.getCurrentSize() );		//assert current size equals 1
		assertTrue( testBag.contains(testInt) ) ;			//assert bag contains added int

	}

	/**
	 * tests that adding duplicate int to populated bag of ints returns true, and that all added ints exist in bag
	 */
	private static void addToPopulatedTester() {
		BagInterface<Integer> testBag = new LinkedBag<>() ;
		Integer[] testValues = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;	//initial values to populate bag

		for ( int i = 0; i < testValues.length; i++ ) {					
			testBag.add( testValues[ i ] );
		}
		
		for ( int i = 0; i < testValues.length; i++ )					//ensure all values were added to bag
		{
			assertTrue( testBag.contains( testValues[ i ] ) ) ;
		}

		int testInt = 5;												//duplicate int to add to bag

		assertTrue( testBag.add(testInt) ) ;							//assert duplicate value add returns true
		assertFalse( testBag.isEmpty() );								//assert is empty returns false
		assertEquals( 12, testBag.getCurrentSize() );					//assert size of bag equals 12
		assertTrue( testBag.contains(testInt) ) ;						//assert bag contains duplicate int
		assertEquals(2, testBag.getFrequencyOf(5));						//assert frequency of 5 is 2

	}

	/**
	 * tests that toString() called on a bag of ints and a bag of strings returns defined results
	 */
	private static void toStringTester() {
		BagInterface<Integer> testIntBag = new LinkedBag<>() ;
		BagInterface<String> testStringBag = new LinkedBag<>() ;
		Integer[] testIntValues = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;
		String[] testStringValues = { "1", "2", "3", "4"};

		for ( int i = 0; i < testIntValues.length; i++ ) {				
			testIntBag.add( testIntValues[ i ] );
		}
		
		for ( int i = 0; i < testStringValues.length; i++ ) {			
			testStringBag.add( testStringValues[ i ] );
		}
		
		String testIntResult = testIntBag.toString();
		
		String testStringResult = testStringBag.toString();

		String expectedIntResult = "0, 1, 2, -3, -4, 5, 4, 3, 3, 2, 1, "; //values will be backwards because nodes are added to front
		
		String expectedStringResult = "4, 3, 2, 1, ";		

		assertEquals(expectedIntResult,testIntResult);
		
		assertEquals(expectedStringResult,testStringResult);
	}

	/**
	 * tests that to string called on a toString() called on an empty bag will return an empty string
	 */
	private static void toStringTesterEmpty() {
		BagInterface<Object> testBag = new LinkedBag<>() ;
		String testResult = testBag.toString();

		String expectedResult = "";							//expected empty string
		

		assertEquals(expectedResult,testResult);
	}

	/**
	 * tests that clear() called on a populated bag removes all entries in the bag
	 */
	private static void clearPopulatedTester() {
		BagInterface<Integer> testBag = new LinkedBag<>() ;
		Integer[] testValues = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;

		for ( int i = 0; i < testValues.length; i++ ) {		
			testBag.add( testValues[ i ] );
		}
		testBag.clear();

		assertEquals(0, testBag.getCurrentSize());			//assert that current size of bag is zero
		assertTrue(testBag.isEmpty());						//assert that the bag is empty

	}

	/**
	 * tests that clear called on an unpopulated bag returns the unpopulated bag
	 */
	private static void clearUnpopulatedTester() {
		BagInterface<Integer> testBag = new LinkedBag<>() ;

		testBag.clear();

		assertEquals(0, testBag.getCurrentSize());			//assert that current size of bag is zero
		assertTrue(testBag.isEmpty());						//assert that the bag is empty

	}

	/**
	 * tests contains(entry) called on a bag populated with the supplied entry returns true
	 */
	private static void containsExistingTester() {
		BagInterface<Integer> testBag = new LinkedBag<>() ;
		Integer[] testValues = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;
		int testInt = 5;

		for ( int i = 0; i < testValues.length; i++ ) {	
			testBag.add( testValues[ i ] );
		}

		assertTrue(testBag.contains(testInt));	

	}

	/**
	 * tests contains(entry) called on a bag populated without the supplied entry returns false
	 */
	private static void containsNonexistingTester() {
		BagInterface<Integer> testBag = new LinkedBag<>() ;
		Integer[] testValues = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;
		int testInt = 15;

		for ( int i = 0; i < testValues.length; i++ ) {	
			testBag.add( testValues[ i ] );
		}
		
		Integer testIntNull = null;
		assertFalse(testBag.contains(testInt));	
		assertFalse(testBag.contains(testIntNull));

	}

	/**
	 *  tests contains(entry) called on a bag empty returns false,
	 *  also tests that contains(entry) called on a bag empty where the entry is null returns false,
	 */
	private static void containsEmptyTester() {
		BagInterface<Integer> testBag = new LinkedBag<>() ;
		int testInt = 5;
		Integer testIntNull = null;
		assertFalse(testBag.contains(testInt));	
		assertFalse(testBag.contains(testIntNull));	
	}

	/**
	 * tests that when difference() called on two empty bags, the result is an empty bag
	 */
	private static void differenceEmptyTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		BagInterface<Integer> testBag2 = new LinkedBag<>() ;

		BagInterface<Integer> dbagTest = testBag1.difference(testBag2);

		assertTrue(dbagTest.isEmpty());						//assert that the resulting bag is empty

		Integer[] emptyArray = {};
		assertArrayEquals(emptyArray, dbagTest.toArray()); 	//assert that the resulting bag is equal to empty array
	}

	/**
	 * tests that when difference() called on two identical bags, the result is an empty bag
	 */
	private static void differenceIdenticalTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		BagInterface<Integer> testBag2 = new LinkedBag<>() ;
		Integer[] testValues2 = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;
		for ( int i = 0; i < testValues2.length; i++ ) {	
			testBag2.add( testValues2[ i ] );
		}

		BagInterface<Integer> dbagTest = testBag1.difference(testBag2);	//assert that the resulting bag is empty

		assertTrue(dbagTest.isEmpty());
		Integer[] emptyArray = {};
		assertArrayEquals(emptyArray, dbagTest.toArray());				//assert that the resulting bag is equal to empty array
	}

	/**
	 *  tests that when difference() called on two unique bags, the result is a bag with the unique values
	 */
	private static void differenceUniqueTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;			
		Integer[] testValues1 = { 1, 3, 3, 5, -4, 2, 1, 0 } ;			
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		BagInterface<Integer> testBag2 = new LinkedBag<>() ;
		Integer[] testValues2 = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;  //Bag2 contains unique values 4, -3
		for ( int i = 0; i < testValues2.length; i++ ) {	
			testBag2.add( testValues2[ i ] );
		}

		BagInterface<Integer> dbagTest = testBag2.difference(testBag1);


		assertEquals(2, dbagTest.getCurrentSize());						//assert size of dBag is 2

		Integer[] expected = { 4, -3 };									
		
		assertArrayEquals( expected, dbagTest.toArray());				//assert that dBag contains 4, -3 
	}

	/**
	 * tests that getCurrentSize of a empty tester returns zero
	 */
	private static void getCurrentSizeEmptyTester() {	

		BagInterface<Integer> testBag = new LinkedBag<>() ;				//create empty Bag
		assertEquals(0, testBag.getCurrentSize());						//assert getCurrent returns zero
		assertTrue(testBag.isEmpty());									//assert isEmpty returns true

	}

	/**
	 * tests that getCurrentSize of a populated tester returns correct size
	 */
	private static void getCurrentSizePopulatedTester() {

		BagInterface<Integer> testBag = new LinkedBag<>() ;				
		Integer[] testValues = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;		

		for ( int i = 0; i < testValues.length; i++ ) {						//create bag of 11 elements
			testBag.add( testValues[ i ] );
		}

		assertEquals(11, testBag.getCurrentSize());							//assert getCurrentSize returns 11
		assertFalse(testBag.isEmpty());										//assert isEmpty returns false
		
	}

	/**
	 * test that getFrequencyOf called on a nonexistent entry returns zero
	 */
	private static void getFrequencyOfNonexistant() {

		BagInterface<Integer> testBag = new LinkedBag<>() ;
		Integer[] testValues = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;	//10 not added to Bag

		for ( int i = 0; i < testValues.length; i++ ) {	
			testBag.add( testValues[ i ] );
		}

		assertEquals(0, testBag.getFrequencyOf(10));					//assert that getFrequencyOf returns zero

	}

	/**
	 * test that getFrequencyOf called on a existent entry returns expected value
	 */
	private static void getFrequencyOfExistant() {

		BagInterface<Integer> testBag = new LinkedBag<>() ;
		Integer[] testValues = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;		//add 3 to Bag twice

		for ( int i = 0; i < testValues.length; i++ ) {	
			testBag.add( testValues[ i ] );
		}

		assertEquals(2, testBag.getFrequencyOf(3));							//assert that getFrequencyOf returns 2

	}

	/**
	 * test that getFrequencyOf called on an empty Bag returns zero
	 */
	private static void getFrequencyOfEmpty() {

		BagInterface<Integer> testBag = new LinkedBag<>() ;

		assertEquals(0, testBag.getFrequencyOf(10));

	}

	/**
	 * tests that intersection called on empty Bags returns an empty Bag
	 */
	public static void intersectionEmptyTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		BagInterface<Integer> testBag2 = new LinkedBag<>() ;

		BagInterface<Integer> ibagTest = testBag1.intersection(testBag2);

		assertTrue(ibagTest.isEmpty());										//assert that ibag is empty

	}

	/**
	 * tests that intersection called on identical Bags returns the elements from the identical bags
	 */
	public static void intersectionIdenticalTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		BagInterface<Integer> testBag2 = new LinkedBag<>() ;
		Integer[] testValues2 = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;
		for ( int i = 0; i < testValues2.length; i++ ) {	
			testBag2.add( testValues2[ i ] );
		}

		BagInterface<Integer> ibagTest = testBag1.intersection(testBag2);

		assertArrayEquals(testValues1, ibagTest.toArray());						//assert that iBag is equal to testBag1
		assertArrayEquals(testValues2, ibagTest.toArray());						//assert that iBag is equal to testBag2

	}

	/**
	 * tests that intersection called on unique Bags returns the common elements from the unique bags,
	 * without mutation errors
	 */
	public static void intersectionUniqueTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 2, 3, 3, 4, -4, -3, 2, 1 } ;					//Bag1 contains all common elements
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		BagInterface<Integer> testBag2 = new LinkedBag<>() ;
		Integer[] testValues2 = { 1, 2, 3, 3, 4, 5, -4, -3, 2, 1, 0 } ;			//Bag2 contains the unique elements
		for ( int i = 0; i < testValues2.length; i++ ) {	
			testBag2.add( testValues2[ i ] );
		}

		BagInterface<Integer> ibagTest = testBag2.intersection(testBag1);

		assertArrayEquals(testValues1, ibagTest.toArray());						//Assert ibag only contains common values (testBag1)
	}

	/**
	 * tests that isEmpty returns true when called on empty bag
	 */
	public static void isEmptyEmptyTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ; //create empty Bag
		assertTrue(testBag1.isEmpty());						 //assert isEmpty returns true
	}

	/**
	 * tests that isEmpty returns false when called on a populated bag
	 */
	public static void isEmptyPopulatedTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 2, 3, 3, 4, -4, -3, 2, 1 } ;		//create populated Bag
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		assertFalse(testBag1.isEmpty());							//assert isEmpty returns false
	}

	/**
	 * tests that when remove is called on a empty bag, null is returned
	 */
	public static void removeEmptyTester() {
		BagInterface<Integer> testBag1 = new LinkedBag<>() ;		//create empty Bag
		assertEquals(null, testBag1.remove());						//assert remove returns null
	}

	/**
	 * tests that when remove is called on a populated bag, the removed value is returned
	 */
	public static void removePopulatedTester() {
		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 2, 3, 3, 4, -4, -3, 2, 1 } ;		//create populated Bag
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		Integer removal = 1;										//value expected to be removed
		assertEquals(removal, testBag1.remove());					//assert removed value equals expected

	}

	/**
	 * tests that when remove<T> is called on a empty bag, false is returned
	 */
	public static void removeTEmptyTester() {
		BagInterface<Integer> testBag1 = new LinkedBag<>() ;

		Integer value = 8;
		assertFalse(testBag1.remove(value));  //assert remove<T> returns false
	}

	/**
	 * tests that when remove<T> is called on a populated bag,
	 * and the supplied entry does not exist, or is null
	 * false is returned
	 */
	public static void removeTNonexistentTester() {
		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 2, 3, 3, 4, -4, -3, 2, 1 } ;
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		Integer removal = 10;					
		assertFalse(testBag1.remove(removal));					//assert remove returns false for nonexistent entry,
		Integer removalNull = null;
		assertFalse(testBag1.remove(removalNull));				//and null value
		
	}

	/**
	 * tests that when remove<T> is called on a populated bag,
	 * and the entry exists
	 * the entry is returned
	 */
	public static void removeTExistentTester() {
		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 2, 3, 3, 4, -4, -3, 2, 1 } ;
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}
		
		Integer removal = 1;						//existent entry
		assertTrue(testBag1.remove(removal));		//assert removed existent entry is returned
	}

	/**
	 * tests that toArray called on an empty Bag returns an empty Array
	 */
	public static void toArrayEmptyTester() {
		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		
		Integer[] result = {};									//Empty Array to compare
		assertArrayEquals(result, testBag1.toArray());			//Assert return equals an empty Array
	
	}

	/**
	 * test that toArray called on a populated Bag returns an expected Array
	 */
	public static void toArrayPopulatedTester() {
		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 2, 3, 3, 4, -4, -3, 2, 1 } ;
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		Integer[] result = {1, 2, -3, -4, 4, 3, 3, 2};			//expected Array
		assertArrayEquals(result, testBag1.toArray());			//assert return equals an expected Array
	}

	/**
	 * tests that union called on 2 empty Bags returns an empty Bag
	 */
	public static void unionEmptyTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		BagInterface<Integer> testBag2 = new LinkedBag<>() ;

		BagInterface<Integer> ibagTest = testBag1.union(testBag2);

		assertTrue(ibagTest.isEmpty());								//Assert iBag equals an empty Bag

	}

	/**
	 * tests that union called on 2 identical Bags,
	 * returns a Bag equal to the elements in the identical Bags,
	 * with the correct frequency
	 */
	public static void unionIdenticalTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 1, 2, 3, 3, 4, 5,} ;
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		BagInterface<Integer> testBag2 = new LinkedBag<>() ;
		Integer[] testValues2 = { 1, 2, 3, 3, 4, 5,} ;
		for ( int i = 0; i < testValues2.length; i++ ) {	
			testBag2.add( testValues2[ i ] );
		}

		BagInterface<Integer> ibagTest = testBag1.union(testBag2); 
		
		Integer[] result = {1, 2, 3, 3, 4, 5, 5, 4, 3, 3, 2, 1, };
		

		assertArrayEquals(result, ibagTest.toArray());  //Assert array equal to the elements in Bag1

	}

	/**
	 * tests that union called on 2 unique arrays,
	 * where no bag contains duplicates,
	 * returns all elements from both arrays,
	 * with the correct frequency
	 */
	public static void unionUniqueTester() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 1, 2, 3, 4, 5 } ;
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		BagInterface<Integer> testBag2 = new LinkedBag<>() ;			//create bag with no duplicate values
		Integer[] testValues2 = { 3, 4, 5, 6, 7 } ;
		for ( int i = 0; i < testValues2.length; i++ ) {	
			testBag2.add( testValues2[ i ] );
		}

		BagInterface<Integer> ibagTest = testBag1.union(testBag2);

		Integer[] result = {1, 2, 3, 4, 5, 7, 6, 5, 4, 3, };			//data from testBag2 in reverse order,
																		//because of add to front
			
		assertArrayEquals(result, ibagTest.toArray());
	}

	/**
	 * tests that union called on 2 unique arrays,
	 * where  bag contains duplicates,
	 * returns all elements from both arrays,
	 * with the correct frequency
	 */
	public static void unionUniqueTester2() {

		BagInterface<Integer> testBag1 = new LinkedBag<>() ;
		Integer[] testValues1 = { 3, 4, 5, 6, 7 } ;
		for ( int i = 0; i < testValues1.length; i++ ) {	
			testBag1.add( testValues1[ i ] );
		}

		BagInterface<Integer> testBag2 = new LinkedBag<>() ;
		Integer[] testValues2 = { 1, 1, 2, 3, 4, 5, } ;				//create bag with duplicate values
		for ( int i = 0; i < testValues2.length; i++ ) {	
			testBag2.add( testValues2[ i ] );
		}

		BagInterface<Integer> ibagTest = testBag1.union(testBag2);
		Integer[] result = { 3, 4, 5, 6, 7, 5, 4, 3, 2, 1, 1, };	//data from testBag2 in reverse order 
																	//because of add to front
		
		assertArrayEquals(result, ibagTest.toArray());			
	}


}	// end class LinkedBag
