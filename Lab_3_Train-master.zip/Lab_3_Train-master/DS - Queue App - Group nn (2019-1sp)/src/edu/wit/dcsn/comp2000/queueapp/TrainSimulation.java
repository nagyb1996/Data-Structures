/*
 * Dave Rosenberg 
 * Comp 2000 - Data Structures 
 * Lab 3: Queue application - Train Simulation 
 * Spring, 2019
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your
 * learning for this course. You may not use this code for any other
 * assignments, in my course or elsewhere, without explicit permission, in
 * advance, from myself (and the instructor of any other course). Further, you
 * may not post or otherwise share this code with anyone other than current
 * students in my sections of this course. Violation of these usage restrictions
 * will be considered a violation of the Wentworth Institute of Technology
 * Academic Honesty Policy.
 */

package edu.wit.dcsn.comp2000.queueapp;

import java.io.FileNotFoundException;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

import edu.wit.dcsn.comp2000.queueapp.Configuration;
import edu.wit.dcsn.comp2000.queueapp.Configuration.PairedLimit;
import edu.wit.dcsn.comp2000.queueapp.Configuration.TrainSpec;
import edu.wit.dcsn.comp2000.queueapp.Configuration.RouteSpec;

/**
 * @author Brody Nagy
 * @author Kyle Ferreira
 * @author Matt Chapman
 * @version 1.0.0
 */

public class TrainSimulation {

	// Array list of all stations
	private static ArrayList<Station> stationObjectList = new ArrayList<>();
	// Array list of all trains
	private static ArrayList<Train> trainObjectList = new ArrayList<>();
	// Array list of all passengers
	private static ArrayList<Passenger> passengerList = new ArrayList<>();

	public static void main(String[] args) throws FileNotFoundException, IOException {

		// write to test log
		Logger.create();

		// Retrieve configuration settings
		Configuration configuration = new Configuration("./data/TrainSimulation.config");

		// get number of ticks
		int numOfTicks = configuration.getTicks();

		// Create additional tick variable to avoid accidental mutation in numOfTicks
		int numTicks = 0;

		// Retrieve pseudoRandom from configuration file
		Random pseudoRandom = new Random(configuration.getSeed());

		// Write to console log file
		Logger.write("\n-----SIMULATION STARTED-----\n");
		Logger.write("\n-----PERFORMING INITIAL SETUP-----\n");
		System.out.println("-----SIMULATION STARTED-----\n");
		System.out.println("-----PERFORMING INITIAL SETUP-----\n");

		// create the route
		TrainRoute theRoute = generateRoutes(configuration);

		// create the stations
		generateStations(configuration, theRoute);

		// create the trains
		generateTrains(configuration, theRoute);

		// create the passengers
		generatePassengers(configuration, theRoute, numTicks, pseudoRandom);

		// put the passengers into the correct station queue
		enqueuePassengers(passengerList, stationObjectList);

		// simulation loop, runs for the number of ticks specified in the configuration

		Logger.write("\n-----INITIAL SETUP COMPLETE-----\n");
		System.out.println("\n-----INITIAL SETUP COMPLETE-----");

		while (numTicks <= numOfTicks) {
			// print to console and log
			System.out.printf("\n-----AT TIME %d-----\n", numTicks);
			Logger.write(String.format("-----AT TIME %d-----", numTicks));

			Logger.write("\n-----PASSENGER STATS-----\n");
			System.out.println("\n-----PASSENGER STATS-----");

			// randomly generate passengers after first tick
			if (numTicks > 0) {

				generatePassengers(configuration, theRoute, numTicks, pseudoRandom);

				// put the new passengers into station queues
				enqueuePassengers(passengerList, stationObjectList);

			}

			Logger.write("\n-----TRAIN STATS-----\n");
			System.out.println("\n-----TRAIN STATS-----");

			// iterates through all the trains
			for (Train currentTrain : trainObjectList) {

				// list to hold disembarking passengers
				ArrayList<Passenger> removedPassenger = new ArrayList<>();
				// list to hold newly boarded passengers
				ArrayList<Passenger> addedPassenger = new ArrayList<>();

				// keep track if the train stats have been printed
				boolean printFlag = false;

				// for each station
				for (Station currentStation : stationObjectList) {
					Location stationLocation = currentStation.getLocation(); // get location of current station
					Direction trainDirection = currentTrain.getLocation().getDirection(); // get direction of train
					// check if current train is at a station
					if (currentTrain.getLocation().compareTo(stationLocation) == 0) {

						// print to console and log
						Logger.write(String.format("Train %d is at Station %d heading %s", currentTrain.getID(),
								currentTrain.getLocation().getPosition(),
								currentTrain.getLocation().getDirection().toString()));

						// train status was printed
						printFlag = true;

						// allow passengers to disembark
						removedPassenger = currentTrain.disembark(stationLocation, numTicks);
						if (!removedPassenger.isEmpty()) {

							Logger.write(
									String.format("The following Passengers disembark from Train %d at Station %d:",
											currentTrain.getID(), currentStation.getLocation().getPosition()));
							Logger.write("\nDISEMBARKED PASSENGER STATS");

							for (Passenger removed : removedPassenger) {
								Logger.write(String.format("%s", removed.toStringDisembark()));
							}
						}

						// allow passengers to board
						addedPassenger = currentStation.board(currentTrain, trainDirection, numTicks);
						if (!addedPassenger.isEmpty()) {

							Logger.write(String.format("The following Passengers board Train %d at Station %d: %s",
									currentTrain.getID(), currentStation.getLocation().getPosition(),
									addedPassenger.toString()));

							Logger.write("\nBOARDED PASSENGER STATS");

							for (Passenger added : addedPassenger) {
								Logger.write(String.format("%s", added.toStringBoard()));
							}

						}
						System.out.printf("Train %d is at Station %d heading %s with %d passengers \n",
								currentTrain.getID(), currentTrain.getLocation().getPosition(),
								currentTrain.getLocation().getDirection().toString(),
								currentTrain.getPassengers().size());
						Logger.write(
								String.format("Train %d  has the following %d Passengers: %s", currentTrain.getID(),
										currentTrain.getPassengers().size(), currentTrain.getPassengers().toString()));

					}
				}

				// if the train status hasnt been printed
				if (!printFlag) {
					System.out.printf("Train %d is at Position %d heading %s with %d passengers \n",
							currentTrain.getID(), currentTrain.getLocation().getPosition(),
							currentTrain.getLocation().getDirection().toString(), currentTrain.getPassengers().size());
					Logger.write(String.format("Train %d is at Position %d heading %s ", currentTrain.getID(),
							currentTrain.getLocation().getPosition(),
							currentTrain.getLocation().getDirection().toString()));
					Logger.write(String.format("Train %d  has the following %d Passengers: %s ", currentTrain.getID(),
							currentTrain.getPassengers().size(), currentTrain.getPassengers().toString()));
				}

			}

			// Print all station passenger queues
			Logger.write("\n-----STATION STATS-----\n");
			System.out.println("\n-----STATION STATS-----");
			for (Station currentStationToPrint : stationObjectList) {
				System.out.printf("Station %d: Inbound Queue: %d, Outbound Queue: %d \n",
						currentStationToPrint.getLocation().getPosition(),
						currentStationToPrint.numberInQueue(Direction.INBOUND),
						currentStationToPrint.numberInQueue(Direction.OUTBOUND));
				Logger.write(String.format("Station %d has the following passengers: %s \n",
						currentStationToPrint.getLocation().getPosition(), currentStationToPrint.queueToString()));
			}

			// move the trains
			for (Train trainToMove : trainObjectList) {
				trainToMove.getLocation().move();
			}

			if (numTicks == numOfTicks) {

				// close the log
				Logger.write("\n\n-----SIMULATION ENDED-----\n");
				Logger.write("\n-----ENDING STATS-----\n");
				Logger.write("\n-----TRAIN STATS-----\n");
				System.out.println("\n-----SIMULATION ENDED-----\n");
				System.out.println("\n-----ENDING STATS-----\n");
				System.out.println("-----TRAIN STATS-----");

				// iterates through all the trains
				for (Train currentTrain : trainObjectList) {

					// list to hold disembarking passengers
					ArrayList<Passenger> removedPassenger = new ArrayList<>();
					// list to hold newly boarded passengers
					ArrayList<Passenger> addedPassenger = new ArrayList<>();

					// keep track if the train stats have been printed
					boolean printFlag = false;

					// for each station
					for (Station currentStation : stationObjectList) {
						Location stationLocation = currentStation.getLocation(); // get location of current station
						Direction trainDirection = currentTrain.getLocation().getDirection(); // get direction of train
						// check if current train is at a station
						if (currentTrain.getLocation().compareTo(stationLocation) == 0) {

							// print to console and log
							Logger.write(String.format("Train %d is at Station %d heading %s", currentTrain.getID(),
									currentTrain.getLocation().getPosition(),
									currentTrain.getLocation().getDirection().toString()));

							// train status was printed
							printFlag = true;

							System.out.printf("Train %d is at Station %d heading %s with %d passengers \n",
									currentTrain.getID(), currentTrain.getLocation().getPosition(),
									currentTrain.getLocation().getDirection().toString(),
									currentTrain.getPassengers().size());
							Logger.write(String.format("Train %d  has the following %d Passengers: %s",
									currentTrain.getID(), currentTrain.getPassengers().size(),
									currentTrain.getPassengers().toString()));

						}
					}

					// if the train status hasnt been printed
					if (!printFlag) {
						System.out.printf("Train %d is at Position %d heading %s with %d passengers \n",
								currentTrain.getID(), currentTrain.getLocation().getPosition(),
								currentTrain.getLocation().getDirection().toString(),
								currentTrain.getPassengers().size());
						Logger.write(String.format("Train %d is at Position %d heading %s ", currentTrain.getID(),
								currentTrain.getLocation().getPosition(),
								currentTrain.getLocation().getDirection().toString()));
						Logger.write(
								String.format("Train %d  has the following %d Passengers: %s ", currentTrain.getID(),
										currentTrain.getPassengers().size(), currentTrain.getPassengers().toString()));
					}

				}

				// Print all station passenger queues
				Logger.write("\n-----STATION STATS-----\n");
				System.out.println("\n-----STATION STATS-----");
				for (Station currentStationToPrint : stationObjectList) {
					System.out.printf("Station %d: Inbound Queue: %d, Outbound Queue: %d \n",
							currentStationToPrint.getLocation().getPosition(),
							currentStationToPrint.numberInQueue(Direction.INBOUND),
							currentStationToPrint.numberInQueue(Direction.OUTBOUND));
					Logger.write(String.format("Station %d has the following passengers: %s \n",
							currentStationToPrint.getLocation().getPosition(), currentStationToPrint.queueToString()));
				}

				Logger.close();

			}

			// increment the number of ticks
			numTicks++;
		} // end while

	}

	// method for generating Routes
	public static TrainRoute generateRoutes(Configuration configuration) {
		TrainRoute theRoute = new TrainRoute(configuration.getRoute()); // retrieve the train route from configuration

		RouteSpec theRouteSpec = configuration.getRoute(); // retrieve the train route specs from configuration

		System.out.printf("The Train Route is:%n\t%s is %s with length %,d%n", theRoute, theRoute.getStyle(),
				theRoute.getLength());

		Logger.write(String.format("The Train Route is:%n\t%s is %s with length %,d%n", theRoute, theRoute.getStyle(),
				theRoute.getLength()));

		return theRoute;

	}

	// method for creating passengers
	public static void generatePassengers(Configuration configuration, TrainRoute theRoute, int numTicks,
			Random pseudoRandom) {

		// Retrieve stationSpecs from Configuration file
		int[] theStationSpecs = configuration.getStations();

		// Retrieve passengerSpecs from Configuration file
		PairedLimit[] thePassengerSpecs = configuration.getPassengers();

		// code to generate a random number of passengers each tick after time is
		// greater than 0
		if (numTicks > 0) {

			// get maximum and minimum number of passengers to generate
			int minimumPassengers = thePassengerSpecs[Configuration.PASSENGERS_PER_TICK].minimum;
			int maximumPassengers = thePassengerSpecs[Configuration.PASSENGERS_PER_TICK].maximum;

			int nextRandomNumber = pseudoRandom.ints(minimumPassengers, maximumPassengers).findFirst().getAsInt();

			// get pseudoRandom number of passengers to generate
			int newPassengerCount = nextRandomNumber;

			// print to log and console
			System.out.printf("%d passengers are created at time %d:", newPassengerCount, numTicks);
			Logger.write(String.format("%d passengers are created at time %d:", newPassengerCount, numTicks));

			for (int passengerCount = 1; passengerCount <= newPassengerCount; passengerCount++) {
				Passenger aPassenger = new Passenger(
						new Location(theRoute, theStationSpecs[pseudoRandom.nextInt(theStationSpecs.length)],
								Direction.NOT_APPLICABLE),
						new Location(theRoute, theStationSpecs[pseudoRandom.nextInt(theStationSpecs.length)],
								Direction.NOT_APPLICABLE),
						numTicks // current time indicates that clock hasn't started
				);

				passengerList.add(aPassenger);
				Logger.write(aPassenger.toStringCreation());

			} // end for()

		}

		// generate initial passengers if time is 0
		else if (numTicks == 0) {

			// get maximum and minimum number of passengers to generate
			int minimumPassengers = thePassengerSpecs[Configuration.PASSENGERS_INITIAL].minimum;
			int maximumPassengers = thePassengerSpecs[Configuration.PASSENGERS_INITIAL].maximum;

			// get initial pseudoRandom number of passengers to generate
			int newPassengerCount = minimumPassengers == maximumPassengers ? minimumPassengers
					: pseudoRandom.nextInt(maximumPassengers - minimumPassengers) + minimumPassengers + 1;

			System.out.printf("%d passengers are created at time %d:", newPassengerCount, numTicks);
			Logger.write(String.format("%d passengers are created at time %d:", newPassengerCount, numTicks));

			for (int passengerCount = 1; passengerCount <= newPassengerCount; passengerCount++) {
				Passenger aPassenger = new Passenger(
						new Location(theRoute, theStationSpecs[pseudoRandom.nextInt(theStationSpecs.length)],
								Direction.NOT_APPLICABLE),
						new Location(theRoute, theStationSpecs[pseudoRandom.nextInt(theStationSpecs.length)],
								Direction.NOT_APPLICABLE),
						0 // current time indicates that clock hasn't started
				);

				passengerList.add(aPassenger);
				Logger.write(aPassenger.toStringCreation());

			} // end for()

		}

	}

	// method for creating new stations
	public static void generateStations(Configuration configuration, TrainRoute theRoute) {

		// Retrieve stationSpecs from configuration file
		int[] theStationSpecs = configuration.getStations();
		// Print to log and console
		System.out.println("The following stations are created:");
		Logger.write("The following stations are created:");

		// for each station position in stationSpecs
		for (int stationPosition : theStationSpecs) {
			Station aStation = new Station(theRoute, stationPosition); // create a new station
			stationObjectList.add(aStation); // add station to station ArrayList
			System.out.printf("\t%s is %s%n", aStation, aStation.getLocation()); // print station to console
			Logger.write(String.format("\t%s is %s%n", aStation, aStation.getLocation()));
		}

	}

	// method for creating new trains
	public static void generateTrains(Configuration configuration, TrainRoute theRoute) {

		// retrieve train specifications from configuration file
		TrainSpec[] theTrainSpecs = configuration.getTrains();

		// print to console and log
		System.out.println("The following Trains are created:");
		Logger.write("The following Trains are created:");
		// for each
		for (TrainSpec aTrainSpecification : theTrainSpecs) {
			Train aTrain = new Train(theRoute, aTrainSpecification);
			System.out.printf("\t%s is %s with capacity %,d%n", aTrain, aTrain.getLocation(), aTrain.getCapacity());
			Logger.write(String.format("\t%s is %s with capacity %,d%n", aTrain, aTrain.getLocation(),
					aTrain.getCapacity()));
			trainObjectList.add(aTrain);
		}

	}

	public static void enqueuePassengers(ArrayList<Passenger> passengerList, ArrayList<Station> stationObjectList) {

		// Iterate through all stations in station list
		for (Station station : stationObjectList) {
			Queue<Passenger> passengerQueueIN = new LinkedList<Passenger>(); // queue for in bound passengers
			Queue<Passenger> passengerQueueOUT = new LinkedList<Passenger>();// queue for out bound passengers

			ArrayList<Passenger> passengersQueuedList = passengerList;
			Iterator<Passenger> i = passengersQueuedList.iterator();

			Direction direction = null;

			// Iterate through passengers
			while (i.hasNext()) {
				Passenger passenger = i.next(); // get passenger
				Location location = passenger.getFrom(); // get station traveling from
				if (passenger.getFrom().compareTo(passenger.getTo()) > 0) {
					direction = Direction.INBOUND;
					if (station.getLocation().compareTo(location) == 0) {
						passengerQueueIN.add(passenger);
						i.remove();
					}
				}

				else if (passenger.getFrom().compareTo(passenger.getTo()) < 0) {
					direction = Direction.OUTBOUND;
					if (station.getLocation().compareTo(location) == 0) {
						passengerQueueOUT.add(passenger);
						i.remove();
					}
				}
			}

			station.platformActions(passengerQueueIN, Direction.INBOUND);
			station.platformActions(passengerQueueOUT, Direction.OUTBOUND);

		}
	}

}