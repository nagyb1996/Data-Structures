/*
 * Dave Rosenberg 
 * Comp 2000 - Data Structures 
 * Lab 3: Queue application - Train Simulation 
 * Spring, 2019
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your
 * learning for this course. You may not use this code for any other
 * assignments, in my course or elsewhere, without explicit permission, in
 * advance, from myself (and the instructor of any other course). Further, you
 * may not post or otherwise share this code with anyone other than current
 * students in my sections of this course. Violation of these usage restrictions
 * will be considered a violation of the Wentworth Institute of Technology
 * Academic Honesty Policy.
 */

/**
 * Representation of a station on a train route. A Station has two platforms
 * (queues) where Passengers wait before boarding a train. Passengers wait on
 * the platform which serves trains traveling in the direction that can take
 * them to their destination in the least time.
 * 
 * <p>
 * NOTE: This class is incomplete - you may want to restructure it based on your
 * implementation's requirements.
 */

package edu.wit.dcsn.comp2000.queueapp;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Representation of a station on a train route. A Station has two platforms
 * (queues) where Passengers wait before boarding a train. Passengers wait on
 * the platform which serves trains traveling in the direction that can take
 * them to their destination in the least time.
 * 
 * @author David M Rosenberg
 * @author Brody Nagy
 * @author Kyle Ferreira
 * @author Matt Chapman
 * @version 1.0.0 base version
 */
public final class Station {
	// class-wide/shared information
	private static int nextId = 1; // enables automatic id assignment

	// per-instance fields
	private final int id; // unique id for this station

	private final Location location;
	private HashMap<Direction, Queue<Passenger>> platforms;

	/**
	 * @param onRoute         the instance of the TrainRoute on which this Train
	 *                        operates
	 * @param positionOnRoute the specifications from the configuration file
	 */
	public Station(TrainRoute onRoute, int positionOnRoute) {
		id = Station.nextId++; // assign the next unique id

		// create a collection of platforms, determine the directions based on the route
		// style,
		// and create a pair of platforms indexable by the direction they service
		platforms = new HashMap<>();

		Direction oneDirection = onRoute.getStyle() == RouteStyle.LINEAR ? Direction.OUTBOUND : Direction.CLOCKWISE;
		platforms.put(oneDirection, new LinkedList<Passenger>());
		platforms.put(oneDirection.reverse(), new LinkedList<Passenger>());

		// save the position along the route
		location = new Location(onRoute, positionOnRoute, Direction.STATIONARY);

		System.out.println(platforms.toString());

	} // end 2-arg constructor

	/**
	 * Retrieves the location for this station
	 * 
	 * @return the location object for this station
	 */

	/**
	 * Puts given passengers in the stations platform queues
	 * 
	 * @param passengers
	 * @param direction
	 */
	public void platformActions(Queue<Passenger> passengers, Direction direction) {
		platforms.put(direction, passengers);
	}

	/**
	 * boards passengers from station queues onto trains going in the direction of
	 * their destination while there is room on the train
	 * 
	 * @param currentTrain
	 * @param direction
	 * @param currentTime
	 * @return
	 */
	public ArrayList<Passenger> board(Train currentTrain, Direction direction, int currentTime) {

		// Array list to track newly boarded passengers
		ArrayList<Passenger> boardedPassengers = new ArrayList<Passenger>();

		// if the train is headed outbound
		if (direction == Direction.OUTBOUND) {
			Queue<Passenger> outBoundPassengers = platforms.get(direction); // store queue of passengers headed outbound
			// while the train is not full and there are passengers to board
			while (!outBoundPassengers.isEmpty() && !currentTrain.isFull()) {
				Passenger passenger = outBoundPassengers.peek(); // Retrieve passenger to board
				outBoundPassengers.remove(); // remove passenger to board from queue
				currentTrain.boardPassengers(passenger); // board the retrieved passenger
				boardedPassengers.add(passenger); // add passenger to list of boarded passengers
				passenger.setTimeBoarded(currentTime); // update retrieved passengers' boarding time
			}
		}
		// Identical to outbound if(), but for inbound passengers
		if (direction == Direction.INBOUND) {
			Queue<Passenger> outBoundPassengers = platforms.get(direction);
			while (!outBoundPassengers.isEmpty() && !currentTrain.isFull()) {
				Passenger passenger = outBoundPassengers.peek();
				outBoundPassengers.remove();
				currentTrain.boardPassengers(passenger);
				boardedPassengers.add(passenger);
				passenger.setTimeBoarded(currentTime);
			}
		}

		return boardedPassengers;

	}

	/**
	 * returns string of passengers in platform queues
	 * 
	 * @return
	 */
	public String queueToString() {
		String result;

		result = platforms.toString();

		return result;
	}

	/**
	 * Gets the number of passengers in a stations queue
	 * 
	 * @param platform direction, to select either inbound or outbound queue
	 * @return number of passengers in selected queue
	 */
	public int numberInQueue(Direction direction) 	{
		Queue<Passenger> passengersOnPlatform = platforms.get(direction);
		
		int numberOfPassengers = passengersOnPlatform.size();

		return numberOfPassengers;
	}

	/**
	 * Returns a stations location
	 * 
	 * @return
	 */
	public Location getLocation() {
		return location;
	} // end getLocation()

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return String.format("%s %,d", getClass().getSimpleName(), id);
	} // end toString()

	// TODO complete this

	/**
	 * Unit test driver
	 * 
	 * @param args -unused-
	 * @throws FileNotFoundException see {@link Configuration#Configuration()}
	 */
	public static void main(String[] args) throws FileNotFoundException {
		Configuration theConfig = new Configuration();

		TrainRoute theRoute = new TrainRoute(theConfig.getRoute());
		int[] theStationSpecs = theConfig.getStations();

		System.out.printf("Using configuration:%n\t%s%n", Arrays.toString(theStationSpecs));

		System.out.println("The result is:");

		for (int stationPosition : theStationSpecs) {
			Station aStation = new Station(theRoute, stationPosition);
			System.out.printf("\t%s is %s%n", aStation, aStation.getLocation());
		} // end foreach()
	} // end test driver main()

} // end class TrainRoute
