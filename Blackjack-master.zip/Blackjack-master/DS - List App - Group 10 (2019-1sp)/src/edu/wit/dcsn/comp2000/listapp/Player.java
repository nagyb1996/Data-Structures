/*
 * Dave Rosenberg
 * Brody Nagy
 * Matt Champan
 * Group 10
 * Blackjack
 * Comp 2000 - Data Structures
 * Lab: List application - card game
 * Spring, 2019
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your
 * learning for this course. You may not use this code for any other
 * assignments, in my course or elsewhere, without explicit permission, in
 * advance, from myself (and the instructor of any other course).
 * 
 * Further, you may not post or otherwise share this code with anyone other than
 * current students in my sections of this course. Violation of these usage
 * restrictions will be considered a violation of the Wentworth Institute of
 * Technology Academic Honesty Policy.
 */

package edu.wit.dcsn.comp2000.listapp;

import edu.wit.dcsn.comp2000.listapp.Hand;

import static org.junit.Assert.assertTrue;

/**
 * 
 * 
 * @author David Rosenberg
 * @author Brody Nagy
 * @author Matt Chapman
 *
 */
public class Player {

	protected static int nextID = 1; // unique ID for player

	protected Hand hand; // players hand
	protected int playerID; // players unique ID
	protected String playerName; // players displayed name, can be a duplicate with another player
	protected int chips; // players chip count
	protected int currentBet; // players current bet
	protected boolean bust; // track if player has busted
	protected boolean blackjack; // track if player has blackjack

	/**
	 * Player constructor
	 * 
	 * @param name - players display name
	 */
	public Player(String name) {
		this.playerID = Player.nextID++;
		this.playerName = name;
		this.hand = new Hand();
		this.bust = false;
		this.chips = 250;
		this.currentBet = 0;
		this.blackjack = false;
	} // end constructor

	/**
	 * Player toString method
	 * 
	 * @return String of Player ID, name and chip count
	 */
	public String playerToString() {
		return "Player " + this.playerID + ": " + this.playerName + "\nChips: " + this.chips;
	}

	/**
	 * Add chips to players total chips
	 * 
	 * @param chipsRecieved chips to add
	 */
	public void recieveChips(int chipsRecieved) {
		this.chips += chipsRecieved;
	}

	/**
	 * Add card to players hand, calls Hand addCard() method
	 * 
	 * @param cardDealt card to add
	 * @param visible   boolean to see if card should be added to visible hand
	 */
	public void addCard(Card cardDealt) {
		this.hand.addCard(cardDealt);
	}

	/**
	 * Accessor for players chipCount
	 * 
	 * @return players chipCount
	 */
	public int chipCount() {
		return this.chips;
	}

	/**
	 * Calls Hands printHand() method
	 * 
	 * @return string of players hand
	 */
	public String printHand() {
		return this.hand.printHand();
	}

	/**
	 * Reinitializes player values
	 */
	public void resetPlayer() {
		this.hand.clear();
		this.bust = false;
		this.currentBet = 0;
		this.blackjack = false;
	}

	/**
	 * Players name accessor
	 * 
	 * @return players name
	 */
	public String getName() {
		return this.playerName;
	}

	/**
	 * Accessor for player ID
	 * 
	 * @return players unique ID
	 */
	public int getID() {
		return this.playerID;
	}

	/**
	 * Accessor for player blackjack boolean
	 * 
	 * @return boolean indicator that is positive if a player has blackjack
	 */
	public boolean hasBlackjack() {
		return this.blackjack;
	}

	/**
	 * Mutator for blackjack boolean
	 */
	public void setBlackjack() {
		this.blackjack = true;
	}

	/**
	 * Accessor for handTotal, calls Hands handTotal() method
	 * 
	 * @return numeric value of players hand
	 */
	public int handTotal() {
		return this.hand.handTotal();
	}

	/**
	 * Resets the nextID int to begin reassigning IDs
	 */
	public static void resetID() {
		nextID = 1;
	}

	/**
	 * Removes chips from a player and adds them to current bet, only allows values
	 * between table minimum and players total chip count
	 * 
	 * @param bet amount a player wish to bet
	 * @return boolean if the bet is a valid amount
	 */
	public boolean placeBet(int bet) {
		boolean valid = false;

		if (bet >= 5 && bet <= this.chipCount()) {
			this.currentBet = bet;
			this.chips = chips - bet;
			valid = true;
		}

		return valid;
	}

	/**
	 * bet accessor
	 * 
	 * @return currentBet of player
	 */
	public int getBet() {
		return this.currentBet;
	}

	/**
	 * boolean bust mutator
	 * 
	 * @param boolean that player has or has not busted
	 */
	public void setBust(boolean busted) {
		this.bust = busted;
	}

	/**
	 * boolean bust accessor
	 * 
	 * @return boolean that indicates if a player has busted
	 */
	public boolean getBust() {
		return this.bust;
	}

	/**
	 * Test driver for Player class, tests are in alphabetical order
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		addCardTest();
		chipCountTest();
		getBetTest();
		getBustTest();
		getIDTest();
		getNameTest();
		handTotalTest();
		hasBlackjackTest();
		placeBetTest();
		playerToStringTest();
		printHandTest();
		recieveChipsTest();
		resetIDTest();
		resetPlayerTest();
		setBlackjackTest();
		setBustTest();

	} // end main()

	/**
	 * Tests playerToString() method
	 */
	private static void playerToStringTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		String actual = testPlayer.playerToString();

		String expected = "Player 1: Test\nChips: 250";

		assertTrue(expected.equals(actual));

	}

	/**
	 * Tests addCard() method
	 */
	private static void addCardTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		Card seven = new Card(Rank.SEVEN, Suit.CLUBS);

		testPlayer.addCard(seven);

		String expected = "|7♣|\nSum: 7";

		assertTrue(testPlayer.printHand().equals(expected));
	}

	/**
	 * Tests placeBet() method
	 */
	private static void placeBetTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		assertTrue(testPlayer.chipCount() == 250);

		assertTrue(testPlayer.placeBet(50));

		assertTrue(testPlayer.chipCount() == 200);

	}

	/**
	 * Test printHand() method
	 */
	private static void printHandTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		Card seven = new Card(Rank.SEVEN, Suit.CLUBS);

		testPlayer.addCard(seven);

		String expected = "|7♣|\nSum: 7";

		// System.out.println(testPlayer.printHand());

		assertTrue(testPlayer.printHand().equals(expected));

	}

	/**
	 * Tests resetPlayer() method
	 */
	private static void resetPlayerTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		String actual = testPlayer.playerToString();

		String expected = "Player 1: Test\nChips: 250";

		assertTrue(expected.equals(actual));

		testPlayer = new Player("Test");

		actual = testPlayer.playerToString();

		expected = "Player 2: Test\nChips: 250";

		assertTrue(expected.equals(actual));

		Player.resetID();

		Player.resetID();

		testPlayer = new Player("Test");

		actual = testPlayer.playerToString();

		expected = "Player 1: Test\nChips: 250";

	}

	/**
	 * Tests recieveChips() method
	 */
	private static void recieveChipsTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		testPlayer.recieveChips(500);

		assertTrue(testPlayer.chipCount() == 750);

	}

	/**
	 * Tests chipCount() method
	 */
	private static void chipCountTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		assertTrue(testPlayer.chipCount() == 250);

	}

	/**
	 * Tests getName() method
	 */
	private static void getNameTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		assertTrue(testPlayer.getName().equals("Test"));

	}

	/**
	 * Tests getID() method
	 */
	private static void getIDTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		assertTrue(testPlayer.getID() == 1);

		testPlayer = new Player("Test");

		assertTrue(testPlayer.getID() == 2);

		testPlayer = new Player("Test");

		assertTrue(testPlayer.getID() == 3);

		Player.resetID();

		testPlayer = new Player("Test");

		assertTrue(testPlayer.getID() == 1);

	}

	/**
	 * Tests hasBlackjack() method
	 */
	private static void hasBlackjackTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		assertTrue(!testPlayer.hasBlackjack());

	}

	/**
	 * Tests setBlackjack() method
	 */
	private static void setBlackjackTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		assertTrue(!testPlayer.hasBlackjack());

		testPlayer.setBlackjack();

		assertTrue(testPlayer.hasBlackjack());

	}

	/**
	 * Tests handTotal() method
	 */
	private static void handTotalTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		Card seven = new Card(Rank.SEVEN, Suit.CLUBS);

		Card ace = new Card(Rank.ACE, Suit.CLUBS);

		testPlayer.addCard(seven);

		testPlayer.addCard(ace);

		assertTrue(testPlayer.handTotal() == 18);

		testPlayer.addCard(ace);

		assertTrue(testPlayer.handTotal() == 19);

	}

	/**
	 * Tests resetID() method
	 */
	private static void resetIDTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		assertTrue(testPlayer.getID() == 1);

		testPlayer = new Player("Test");

		assertTrue(testPlayer.getID() == 2);

		testPlayer = new Player("Test");

		assertTrue(testPlayer.getID() == 3);

		Player.resetID();

		testPlayer = new Player("Test");

		assertTrue(testPlayer.getID() == 1);

	}

	/**
	 * Tests getBet() method
	 */
	private static void getBetTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		assertTrue(testPlayer.chipCount() == 250);

		assertTrue(testPlayer.placeBet(50));

		assertTrue(testPlayer.chipCount() == 200);

		assertTrue(testPlayer.getBet() == 50);

	}

	/**
	 * Tests setBust() method
	 */
	private static void setBustTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		assertTrue(!testPlayer.getBust());

		testPlayer.setBust(true);

		assertTrue(testPlayer.getBust());

	}

	/**
	 * Tests getBust() method
	 */
	private static void getBustTest() {

		Player.resetID();

		Player testPlayer = new Player("Test");

		assertTrue(!testPlayer.getBust());

		testPlayer.setBust(true);

		assertTrue(testPlayer.getBust());

	}

} // end class Player
