/*
 * Group 10
 * Brody Nagy
 * Matt Champan
 * Comp 2000 - Data Structures
 * Lab: List application - card game
 * Spring, 2019
 */

/**
 * Blackjack game driver
 * 
 * @author Brody Nagy
 * @author Matt Chapman
 * @version 1.0.0
 */

package edu.wit.dcsn.comp2000.listapp;

import edu.wit.dcsn.comp2000.listapp.Player;
import edu.wit.dcsn.comp2000.listapp.Dealer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Blackjack {
	private static List<Player> players = new ArrayList<Player>(); // Holds Players
	private static Dealer dealer; // Dealer for instance of Blackjack
	private static Scanner scanner = new Scanner(System.in); // Get player input from console
	private static Deck deck = new Deck();// Deck for instance of Blackjack
	private static boolean blackjackExists = false;// Track if a Blackjack is dealt
	private static boolean playAgain = true;// Track if player wants to continue playing
	private static int tableMinimum = 5; // Minimum bet per hand

	/**
	 * Driver for simulation, calls all methods in Blackjack
	 */
	public static void main(String[] args) {
		System.out.println("*******Starting Game*******");
		// create players, dealer
		initialSetup();

		// While the player wants to keep playing
		while (playAgain) {

			// start betting
			System.out.println("\n*******Begin Betting*******\n");
			recieveBets();

			// Deal cards to players and dealer
			System.out.println("\n*******Dealing Cards*******");
			dealCards();

			// Check for BlackJack
			checkForBlackjack();

			// If there are no Blackjacks
			if (!blackjackExists) {
				// prompt for player actions
				playerActions();

				// Perform dealer actions
				System.out.println("*******Dealer Actions*******");
				System.out.printf("Dealer: Hand %s\n", dealer.printHand());
				dealerActions();
			}

			// show hands and results
			System.out.println("\n*******Evaluating Hands*******\n");

			// pay bets based on hands
			payBets();

			System.out.println("\n*******Paying Bets*******\n");

			// print chips at end of round
			System.out.println("New Chip Counts:\n");
			printChips();

			System.out.println("\n*******Next Hand?*******\n");

			// check restart
			playAgain();

			// reset fields
			reset();
		}

	} // end main()

	/**
	 * Creates dealer and players
	 */
	private static void initialSetup() {
		createPlayers();
		dealer = new Dealer();

	} // end initialSetup()

	/**
	 * Creates between 1-3 players based on command line input
	 */
	private static void createPlayers() {
		int numPlayers = 0;
		String playerName = "";
		Boolean anInt = false;
		Boolean validNumber = false;

		// while loop prevents an invalid character from being entered
		while (!validNumber) {

			System.out.println("\nPlease enter the number of players participating in this game (1-3)\n");

			do {

				try {
					numPlayers = Integer.parseInt(scanner.nextLine());
					anInt = true;

				} catch (Exception e) {
					System.out.println("Please enter a number");
					scanner.reset();
				}

			} while (!anInt);

			// once a number has been entered, if it is valid, create that number of players
			if (numPlayers == 1 || numPlayers == 2 || numPlayers == 3) {

				List<String> playerNames = new ArrayList<String>(); // list to store names for players

				for (int i = 1; i <= numPlayers; i++) {

					System.out.printf("\nPlease enter a name for Player %d: \n", i);

					playerName = scanner.nextLine();

					// check that entered name is not blank or illegal
					if (playerName.isEmpty() || playerName.equals("Professor Rosenberg")) // just kidding by the way,
																							// please play my game
					{
						System.out.println("You have entered an illegal name, please try again!");
						scanner.reset();
						i--;
					}
					// if the name is valid, create a player with that name
					else {
						playerNames.add(playerName);
						Player temp = new Player(playerName);
						players.add(temp);
					}
				}

				// make sure that the user wants to proceed with the specified players
				System.out.println("\nAre the entered names accurate? (Enter Y for yes and N for no)\n");
				for (int j = 0; j < numPlayers; j++) {
					System.out.printf("Player %d: %s\n", j + 1, playerNames.get(j));
				}

				boolean validOption = false;

				// while loop ensures invalid option cannot be entered
				while (!validOption) {

					String confirmation = scanner.next();

					// if they are satisfied, print the players and being the game
					if (confirmation.matches("Y") || confirmation.matches("y")) {

						System.out.println("\n*******Creating Players*******\n");

						System.out.println("Excellent, here are the current players:");
						printPlayers();
						validOption = true; // exit inner while loop
						validNumber = true; // exit outer while loop
					}

					// if they are not satisfied, remove all players and re-prompt for input
					else if (confirmation.matches("N") || confirmation.matches("n")) {
						System.out.println("Lets try again...");
						players.clear();
						scanner.reset();
						Player.resetID();
						validOption = true; // exit inner while loop
					}

					// invalid option
					else {
						System.out.println("You have entered an illegal option, please enter Y for yes and N for no!");
					}
				}

			}

			// illegal number of characters
			else
				System.out.println("You have entered an illegal number of players, please try again!");
		}
	} // end createPlayers()

	/**
	 * Allows each player to place a between between the table minimum and the
	 * maximum number of chips they possess
	 */
	private static void recieveBets() {
		int numPlayers = players.size();
		boolean valid = false;

		// prompt each player for bet amount
		for (int i = 0; i < numPlayers; i++) {
			do {
				try {
					System.out.printf("%s place your bet", players.get(i).getName());
					System.out.printf("\n(Current chip-count: %d)\n", players.get(i).chipCount());
					System.out.printf("Table minimum: %d \n", tableMinimum);
					int bet = scanner.nextInt();
					valid = players.get(i).placeBet(bet);
				} catch (Exception e) {
					System.out.println("Invalid bet amount, please try again!");
					scanner.next();
				}
			} while (!valid);
		}
	} // end recieveBets()

	/**
	 * Distributes cards from deck to players and dealer
	 */
	private static void dealCards() {
		/*
		 * players are dealt two cards, one at a time, in order player1, player2...
		 * dealer
		 */

		// for loop executes twice to deal two cards
		for (int j = 0; j <= 1; j++) {
			// deal a card to each player
			for (int i = 0; i < players.size(); i++) {

				players.get(i).addCard(deck.deal()); // give the player a card, they are all visible

				// once all players have received a card, the dealer receives a card
				if (i == players.size() - 1) {
					dealer.addCard(deck.deal());
				}
			}
		}
	} // end dealCards()

	/**
	 * Checks all player and dealer hands to see if anyone has Blackjack, method
	 * updates blackjackExists
	 */
	private static void checkForBlackjack() {
		// Check if any player has Blackjack
		for (int i = 0; i < players.size(); i++) {

			int handTotal = players.get(i).handTotal(); // retrieve player handTotal

			if (handTotal == 21) {
				blackjackExists = true; // Update blackjackExists condition
			}
		}
		// Check if the dealer has Blackjack
		if (dealer.handTotal() == 21) {
			blackjackExists = true;
		}
	} // end checkForBlackjack()

	/**
	 * Displays all cards on the table and prompts each player to hit or stay, once
	 * a player has stayed or busted the next player is prompted
	 */
	private static void playerActions() {
		for (int i = 0; i < players.size(); i++) {
			String action = "";

			System.out.println("\n*******Table View:******\n");

			System.out.printf("Dealer Show Card: %s\n", dealer.dealerHand()); // print the dealers visible cards

			// print all the players cards
			for (int j = 0; j < players.size(); j++) {
				System.out.printf("\n%s Cards: %s\n", players.get(j).getName(), players.get(j).printHand());
			}

			System.out.printf("\n*******%s, it's your turn!*******\n", players.get(i).getName());

			// while the player has not busted or stayed, continue to prompt for action
			while (!action.equals("s") && !players.get(i).getBust()) {
				int handTotal = players.get(i).handTotal();

				// if the player has busted, prompt player to enter any character, then prompt
				// next player for action
				if (handTotal > 21) {
					System.out.printf("\n*******%s: BUST*******\n\n", players.get(i).getName());
					players.get(i).setBust(true);
					System.out.printf("\n Enter any charcter to continue! \n", players.get(i).getName());
					try {
						scanner.next();
					} catch (Exception e) {
						System.out.printf("Incorrect, please enter any character!)");
					}
				}

				else {
					boolean validInput = false;
					while (!validInput) {
						System.out.printf("\nWould you like to hit(h) or stand(s)?\n");
						action = scanner.next();
						// if the player want to hit, deal them a card
						if (action.equals("h")) {
							players.get(i).addCard(deck.deal());
							System.out.printf("New Hand %s\n", players.get(i).printHand());
							validInput = true;
						} else if (action.equals("s")) {
							validInput = true;
							// do nothing, moves to next player

						} else {
							System.out.printf("Incorrect, please hit (h) or stay (s)");
						}
					}
				}
			}
		}
	} // end playerActions()

	/**
	 * Decides how many cards the dealer must draw based on players hands
	 */
	private static void dealerActions() {

		// calculate hand total
		int dealerHandTotal = dealer.handTotal();

		// find the value to beat
		int valueToBeat = 0;
		for (Player p : players) {
			if (p.handTotal() >= dealerHandTotal && p.handTotal() < 22) {
				valueToBeat = p.handTotal();
			}
		}

		// if dealer already beats that value
		if (dealerHandTotal > valueToBeat) {
			return; // exit, pay bets will take care of the rest
		}

		// dealer will not hit above seventeen
		else if (dealerHandTotal <= valueToBeat && dealerHandTotal > 17) {
			return;
		}

		// dealer now must draw to beat players
		else {
			// draw while the dealer is not winning and has not busted and does not have
			// more than 17
			while (dealerHandTotal <= 17 && dealerHandTotal <= valueToBeat && !dealer.getBust()) {

				dealer.addCard(deck.deal()); // draw a card
				System.out.printf("Dealer's New Hand %s\n", dealer.printHand()); // print new hand

				dealerHandTotal = dealer.handTotal(); // update hand total

				// check if dealer busts
				if (dealerHandTotal > 21) {
					System.out.printf("Dealer: BUST\n");
					dealer.setBust(true);

				}
			}
		}
	} // end dealerActions()

	/**
	 * Evaluates players and dealer hands and pays/collects bets accordingly
	 */
	private static void payBets() {

		System.out.println("\n*******Final Hands******\n");

		// display all hands
		System.out.printf("Dealer: %s\n", dealer.printHand());

		for (Player p : players) {
			System.out.printf("\n%s Cards: %s\n", p.getName(), p.printHand());
		}

		// normal return rate on bets
		double payRate = 2;

		// if blackjack exists, pay bets under special conditions
		if (blackjackExists) {
			boolean playerBlackjack = false; // track if players have blackjack
			boolean dealerBlackjack = false; // track if dealer has blackjack
			payRate = 2.5; // special blackjack pay rate
			System.out.println("\n*****!!! B L A C K J A C K !!!*****\n");
			System.out.printf("\nPlayers with Blackjack:\n");

			// find players with blackjack
			for (Player p : players) {
				if (p.handTotal() == 21) {
					System.out.printf("%s - %s\n", p.getName(), p.printHand());
					p.setBlackjack();
					playerBlackjack = true; // some players have blackjack
				}
			}

			// see if the dealer has blackjack
			if (dealer.handTotal() == 21) {
				System.out.printf("%s - %s\n", dealer.getName(), dealer.printHand());
				dealer.setBlackjack();
				dealerBlackjack = true; // dealer has blackjack
			}

			System.out.println("\nRESULTS!:");

			// only dealer has blackjack
			if (dealerBlackjack && !playerBlackjack) {
				// take all players bets
				for (Player p : players) {
					int bet = p.getBet();
					dealer.recieveChips(bet);
					System.out.println(p.getName() + " - LOSES");
				}
			}

			// dealer and a number of players have blackjack
			else if (dealerBlackjack && playerBlackjack) {
				for (Player p : players) {
					// players with blackjack push
					if (p.hasBlackjack()) {
						int bet = p.getBet();
						p.recieveChips(bet);
						System.out.println(p.getName() + " - PUSHES");
					}
					// other players lose
					else {
						int bet = p.getBet();
						dealer.recieveChips(bet);
						System.out.println(p.getName() + " - LOSES");
					}
				}
			}

			// only players have blackjack
			else {
				for (Player p : players) {
					// pay the players with blackjack
					if (p.hasBlackjack()) {
						int bet = p.getBet();
						p.recieveChips((int) (bet * payRate));
						System.out.println(p.getName() + " - WINS");
					}
					// return the bets to players that don't
					else {
						int bet = p.getBet();
						p.recieveChips(bet);
						System.out.println(p.getName() + " - KEEPS BET");
					}
				}
			}
		}

		// pay non-blackjack conditions
		else {

			System.out.println("\nRESULTS!:");

			// collect the bets from the players that busted
			for (Player p : players) {
				if (p.getBust()) {
					int bet = p.getBet();
					dealer.recieveChips(bet);
					System.out.println(p.getName() + " - BUSTS");
				}
			}

			// if the dealer busted, pay the players that didn't bust
			if (dealer.getBust()) {
				for (Player p : players) {
					if (!p.getBust()) {
						int bet = p.getBet();
						p.recieveChips((int) (bet * payRate));
						System.out.println(p.getName() + " - WINS");
					}
				}
			}

			// if the dealer didn't bust
			else if (!dealer.getBust()) {
				for (Player p : players) {
					// pay the players that won
					if (p.handTotal() > dealer.handTotal() && !p.getBust()) {
						int bet = p.getBet();
						p.recieveChips((int) (bet * payRate));
						dealer.recieveChips((int) (bet * -1 * payRate));
						System.out.println(p.getName() + " - WINS");
					}
					// push with the players that tied
					else if (p.handTotal() == dealer.handTotal() && !p.getBust()) {
						int bet = p.getBet();
						p.recieveChips(bet);
						System.out.println(p.getName() + " - PUSHES");
					}
					// collect from the players that lost
					else if (p.handTotal() < dealer.handTotal() && !p.getBust()) {
						int bet = p.getBet();
						dealer.recieveChips(bet);
						System.out.println(p.getName() + " - LOSES");
					}

				}

			}

		}

	} // end payBets()

	/**
	 * Prompts player at end of hand to check if game should be reset so another
	 * hand can be played
	 */
	private static void playAgain() {
		// check to see if all players have sufficient chips to meet table minimum bet
		Iterator<Player> playerIterator = players.iterator();
		while (playerIterator.hasNext()) {
			Player temp = playerIterator.next();
			// if the player can't meet the minimum, remove them from the game
			if (temp.chipCount() < 5) {
				System.out.printf("Sorry %s, you can't meet the table minimum, better luck next time!\n",
						temp.getName());
				playerIterator.remove();
			}
		}

		// if there are still players that can meet the minimum, ask if they would
		// like to play another hand
		if (players.size() > 0) {

			System.out.println("\nWould you like to play another hand? (y/n)");
			boolean validInput = false;

			// while loop prevents invalid input
			while (!validInput) {
				String confirmation = scanner.next();
				// if players want to continue playing, game will reset and continue in main
				if (confirmation.matches("Y") || confirmation.matches("y")) {
					System.out.println("Excellent, let's play!");
					playAgain = true;
					validInput = true;
					// if the players don't want to continue, the game will end
				} else if (confirmation.matches("N") || confirmation.matches("n")) {
					System.out.println("Thanks for playing!");
					playAgain = false;
					validInput = true;
				}
				// else invalid input was entered
				else {
					System.out.println("You have entered an illegal option, please enter Y for yes and N for no!");
				}
			}
		}

		// if no players can meet the minimum, the game will end
		else {
			System.out.println("Sorry! All players have insufficent funds! Better luck next time!");
			playAgain = false;
		}
	}// end playAgain()

	/**
	 * Creates new Deck, resets biggestHand, winningPlayer list, blackjackExists
	 * boolean, players and dealer
	 */
	private static void reset() {
		deck = new Deck(); // create new deck
		blackjackExists = false; // reset boolean
		for (Player p : players) {
			p.resetPlayer();// reset player
		}
		dealer.resetPlayer(); // reset dealer
	}// end reset()

	/**
	 * Prints chip counts for all players in the game
	 */
	private static void printChips() {
		for (Player p : players) {
			System.out.printf("%s Chip Count: %d\n", p.getName(), p.chipCount());
		}

	}// end printChips()

	/**
	 * Prints all players currently in the game
	 */
	public static void printPlayers() {
		Iterator<Player> playerIterator = players.iterator(); // player list iterator
		while (playerIterator.hasNext()) {
			Player player = playerIterator.next();
			System.out.println(player.playerToString());
			; // print the player
		}
	} // end printPlayers()

} // end class Blackjack
