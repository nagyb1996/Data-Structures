/*
 * Dave Rosenberg
 * Brody Nagy
 * Matt Champan
 * Group 10
 * Blackjack
 * Comp 2000 - Data Structures
 * Lab: List application - card game
 * Spring, 2019
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your
 * learning for this course. You may not use this code for any other
 * assignments, in my course or elsewhere, without explicit permission, in
 * advance, from myself (and the instructor of any other course).
 * 
 * Further, you may not post or otherwise share this code with anyone other than
 * current students in my sections of this course. Violation of these usage
 * restrictions will be considered a violation of the Wentworth Institute of
 * Technology Academic Honesty Policy.
 */

package edu.wit.dcsn.comp2000.listapp;

import static org.junit.Assert.assertTrue;

/**
 * A pile of cards to represent a players hand
 * 
 * @author David Rosenberg
 * @author Brody Nagy
 * @author Matt Chapman
 *
 */
public class Hand extends Pile {

	/**
	 * Constructor for Hand, uses super class Pile and creates a Pile to store
	 * visible cards
	 */
	public Hand() {
		super();

	} // end constructor

	/**
	 * Calculates the numeric value of a hand
	 * 
	 * @return the total numeric value of this hand
	 */
	public int handTotal() {
		int handTotal = 0;

		// calculate hand total from Rank altPoints
		for (int i = 0; i < this.getSize(); i++) {
			Card c = this.getCard(i);
			handTotal += c.getRank().getAltPoints();
		}

		// if a hand contains an ace and is over 21, use low value of ace (1) for each
		// ace while the total is over 21
		if (this.containsAce() > 0 && handTotal > 21) {
			for (int j = 0; j < this.containsAce(); j++) {
				if (handTotal > 21)
					handTotal -= 10;
			}
		}

		return handTotal;
	}

	/**
	 * Returns a string of visible cards formatted to look like cards along with the
	 * max value of the hand, used to conceal dealers second card
	 * 
	 * @return string of visible cards
	 */
	public String dealerHandToString() {
		String visibleHand = "|⚓| |"; // neat little anchor card to represent a face down card

		Card c = this.getCard(1);
		visibleHand += c.getRank().toString() + c.getSuit().toString() + "|";

		// this method is only called if there is no blackjack, so a face-up 10 or an
		// ace indicates a max total of 20
		if (this.getCard(1).rank.getAltPoints() == 10)
			visibleHand += "\nMax Sum: " + (this.getCard(1).rank.getAltPoints() + 10);

		else if (this.getCard(1).rank.getAltPoints() == 11)
			visibleHand += "\nMax Sum: " + (this.getCard(1).rank.getAltPoints() + 9);

		// if there is not a 10 or ace showing, the max value is the value shown plus 11
		else
			visibleHand += "\nMax Sum: " + (this.getCard(1).rank.getAltPoints() + 11);

		return visibleHand;
	}

	/**
	 * Returns a string of the hand formatted to look like cards along with a
	 * numeric sum of the hand
	 * 
	 * @return string of hand
	 */
	public String printHand() {

		// print cards to look like cards
		String hand = "|";
		for (int i = 0; i < this.getSize(); i++) {
			Card c = this.getCard(i);
			hand += c.getRank().toString() + c.getSuit().toString() + "|";
		}

		// also print the numeric sum of the hand
		hand += "\nSum: " + this.handTotal();

		return hand;
	}

	/**
	 * Test driver for Hand, tests are in alphabetical order
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		testHand();

	} // end main()

	/**
	 * Tests all methods in Hand
	 */
	private static void testHand() {

		// Create and fill testHand
		Hand testHand = new Hand();
		Card testAce = new Card(Rank.ACE, Suit.CLUBS);
		Card testTwo = new Card(Rank.TWO, Suit.CLUBS);
		Card testThree = new Card(Rank.THREE, Suit.CLUBS);
		Card testFour = new Card(Rank.FOUR, Suit.CLUBS);
		Card testFive = new Card(Rank.FIVE, Suit.CLUBS);
		Card testSix = new Card(Rank.SIX, Suit.CLUBS);
		Card testSeven = new Card(Rank.SEVEN, Suit.CLUBS);
		Card testEight = new Card(Rank.EIGHT, Suit.CLUBS);
		Card testNine = new Card(Rank.NINE, Suit.CLUBS);
		Card testTen = new Card(Rank.TEN, Suit.CLUBS);
		Card testJack = new Card(Rank.JACK, Suit.CLUBS);
		Card testQueen = new Card(Rank.QUEEN, Suit.CLUBS);
		Card testKing = new Card(Rank.KING, Suit.CLUBS);
		testHand.addCard(testAce);
		testHand.addCard(testTwo);
		testHand.addCard(testThree);
		testHand.addCard(testFour);
		testHand.addCard(testFive);
		testHand.addCard(testSix);
		testHand.addCard(testSeven);
		testHand.addCard(testEight);
		testHand.addCard(testNine);
		testHand.addCard(testTen);
		testHand.addCard(testJack);
		testHand.addCard(testQueen);
		testHand.addCard(testKing);

		// Test hand total
		assertTrue(testHand.handTotal() == 85);

		// Test printHand() which also subsequently tests handTotal
		String testString = testHand.printHand();
		String expected = "|A♣|2♣|3♣|4♣|5♣|6♣|7♣|8♣|9♣|10♣|J♣|Q♣|K♣|\nSum: 85";
		assertTrue(testString.equals(expected));

		// Test dealerHandToString
		Hand dealerTest = new Hand();
		dealerTest.addCard(testKing);
		dealerTest.addCard(testQueen);
		testString = dealerTest.dealerHandToString();
		expected = "|⚓| |Q♣|\nMax Sum: 20";
		assertTrue(testString.equals(expected));
	}

} // end class Hand
