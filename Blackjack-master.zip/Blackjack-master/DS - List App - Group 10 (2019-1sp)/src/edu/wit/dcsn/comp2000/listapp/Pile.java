/*
 * Dave Rosenberg
 * Brody Nagy
 * Matt Champan
 * Group 10
 * Blackjack
 * Comp 2000 - Data Structures
 * Lab: List application - card game
 * Spring, 2019
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your
 * learning for this course. You may not use this code for any other
 * assignments, in my course or elsewhere, without explicit permission, in
 * advance, from myself (and the instructor of any other course).
 * 
 * Further, you may not post or otherwise share this code with anyone other than
 * current students in my sections of this course. Violation of these usage
 * restrictions will be considered a violation of the Wentworth Institute of
 * Technology Academic Honesty Policy.
 */

package edu.wit.dcsn.comp2000.listapp;

import edu.wit.dcsn.comp2000.listapp.Card;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Represents a general pile of cards
 * 
 * @author David Rosenberg
 * @author Brody Nagy
 * @author Matt Chapman
 *
 */
public class Pile {
	private List<Card> cards;

	/**
	 * Default constructor
	 */
	public Pile() {
		this.cards = new ArrayList<Card>();

	} // end constructor

	/**
	 * Shuffles order of cards in pile
	 */
	public void shuffle() {

		int entries = this.getSize();

		Card[] cardArray = this.toArray();

		for (int j = 0; j <= 52; j++) {
			for (int i = 0; i < entries; i++) {
				int randomIndex = (int) ((entries - 1) * Math.random());
				Card temp = cardArray[i];
				cardArray[i] = cardArray[randomIndex];
				cardArray[randomIndex] = temp;
			}
		}

		this.clear();

		for (int k = 0; k < cardArray.length; k++) {
			this.addCard(cardArray[k]);
		}

	}

	/**
	 * Returns the number of aces in a pile
	 * 
	 * @return number of aces in a pile
	 */
	public int containsAce() {

		int numAces = 0;

		for (Card c : this.toArray()) {
			if (c.getRank() == Rank.ACE) {
				numAces++;
			}
		}

		return numAces;
	}

	/**
	 * Add a card to a Pile
	 * 
	 * @param card to add
	 */
	public void addCard(Card card) {
		this.cards.add(card);
	}

	/**
	 * Return size of Pile
	 * 
	 * @return size of a Pile
	 */
	public int getSize() {
		return this.cards.size();
	}

	/**
	 * Return a card at index i
	 * 
	 * @param i index of card to return
	 * @return card at index i
	 */
	public Card getCard(int i) {
		return this.cards.get(i);
	}

	/**
	 * Get rank of card at index i
	 * 
	 * @param i index of card to retrieve rank
	 * @return rank of card at index i
	 */
	public String getRank(int i) {

		return this.cards.get(i).getRank().toString();

	}

	/**
	 * Get suit of card at index i
	 * 
	 * @param i index of card to retrieve suit
	 * @return suit of card at index i
	 */
	public String getSuit(int i) {

		return this.cards.get(i).getSuit().graphic;

	}

	/**
	 * remove and return card from index i
	 * 
	 * @param i
	 * @return
	 */
	public Card removeCard(int i) {
		Card removedCard = this.cards.remove(i);
		return removedCard;
	}

	/**
	 * clears pile using arrayList clear() method
	 */
	public void clear() {
		this.cards.clear();
	}

	/**
	 * Piles toArray method
	 * 
	 * @return array of cards, of the cards in a pile
	 */
	public Card[] toArray() {

		int i = 0;
		Card[] cardArray = new Card[this.cards.size()];

		Iterator<Card> cardIterator = this.cards.iterator();
		while (cardIterator.hasNext()) {
			cardArray[i] = cardIterator.next();
			i++;
		}

		return cardArray;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		String cards = "";

		for (int i = 0; i < this.getSize(); i++) {
			String rank = this.getRank(i);
			String suit = this.cards.get(i).suit.graphic;
			cards += rank + " " + suit + "\n";
		}

		return cards;

	} // end toString()

	/**
	 * Test driver for Pile, tests are in alphabetical order
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		addCardTest();
		clearTest();
		containsAceTest();
		getCardTest();
		getRankTest();
		getSuitTest();
		removeCardTest();
		suffleTest();
		toArrayTest();
		toStringTest();

	} // end main()

	/**
	 * Tests shuffle() method by asserting a string of pile does not equal another
	 * string of the same pile after being shuffled
	 */
	private static void suffleTest() {

		Pile testPile = new Pile();

		// create a card for each suit and rank-- 52 cards total
		for (Suit aSuit : Suit.values()) {
			for (Rank aRank : Rank.values()) {
				testPile.addCard(new Card(aRank, aSuit));
			}
		}

		String deck = testPile.toString();

		testPile.shuffle();

		String shufled = testPile.toString();

		assertTrue(!shufled.equals(deck));

	}

	/**
	 * Tests containsAce() method be ensuring that it returns the expected number of
	 * aces in a pile
	 * 
	 */
	private static void containsAceTest() {

		Pile testPile = new Pile();

		Card card = new Card(Rank.SEVEN, Suit.CLUBS);

		testPile.addCard(card);

		assertTrue(testPile.containsAce() == 0);

		card = new Card(Rank.ACE, Suit.SPADES);

		testPile.addCard(card);

		assertTrue(testPile.containsAce() == 1);

		card = new Card(Rank.ACE, Suit.CLUBS);

		testPile.addCard(card);

		assertTrue(testPile.containsAce() == 2);

	}

	/**
	 * Tests addCard() method by ensuring that a card is correctly added to a pile
	 */
	private static void addCardTest() {

		Pile testPile = new Pile();

		Card card = new Card(Rank.SEVEN, Suit.CLUBS);

		testPile.addCard(card);

		assertTrue(testPile.getCard(0) == card);

		assertTrue(testPile.getSize() == 1);

	}

	/**
	 * Tests getCard() method by ensuring that the expected card is returned from a
	 * Pile
	 */
	private static void getCardTest() {

		Pile testPile = new Pile();

		Card seven = new Card(Rank.SEVEN, Suit.CLUBS);

		testPile.addCard(seven);

		Card ace = new Card(Rank.ACE, Suit.CLUBS);

		testPile.addCard(ace);

		assertTrue(testPile.getCard(0) == seven);

		assertTrue(testPile.getCard(1) == ace);

		assertTrue(testPile.getSize() == 2);

	}

	/**
	 * Tests getRank() method by ensuring that the expected rank of a card is
	 * returned
	 */
	private static void getRankTest() {

		Pile testPile = new Pile();

		Card seven = new Card(Rank.SEVEN, Suit.CLUBS);

		testPile.addCard(seven);

		Card ace = new Card(Rank.ACE, Suit.CLUBS);

		testPile.addCard(ace);

		assertTrue(testPile.getRank(0) == Rank.SEVEN.getGraphic());

		assertTrue(testPile.getRank(1) == Rank.ACE.getGraphic());

	}

	/**
	 * Tests getSuit() method by ensuring that the expected suit of a card is
	 * returned
	 */
	private static void getSuitTest() {

		Pile testPile = new Pile();

		Card seven = new Card(Rank.SEVEN, Suit.CLUBS);

		testPile.addCard(seven);

		Card ace = new Card(Rank.ACE, Suit.CLUBS);

		testPile.addCard(ace);

		assertTrue(testPile.getSuit(0) == Suit.CLUBS.graphic);

		assertTrue(testPile.getSuit(1) == Suit.CLUBS.graphic);
	}

	/**
	 * Test removeCard() method by ensuring that the expected card is removed
	 */
	private static void removeCardTest() {

		Pile testPile = new Pile();

		Card nine = new Card(Rank.NINE, Suit.SPADES);

		testPile.addCard(nine);

		Card ace = new Card(Rank.ACE, Suit.CLUBS);

		testPile.addCard(ace);

		Card seven = new Card(Rank.SEVEN, Suit.SPADES);

		testPile.addCard(seven);

		Card queen = new Card(Rank.QUEEN, Suit.SPADES);

		testPile.addCard(queen);

		Card ten = new Card(Rank.TEN, Suit.SPADES);

		testPile.addCard(ten);

		Card four = new Card(Rank.FOUR, Suit.HEARTS);

		testPile.addCard(four);

		assertTrue(testPile.removeCard(0) == nine);

		assertTrue(testPile.removeCard(0) == ace);

		assertTrue(testPile.removeCard(0) == seven);

		assertTrue(testPile.removeCard(0) == queen);

		assertTrue(testPile.removeCard(1) == four);

		assertTrue(testPile.removeCard(0) == ten);

	}

	/**
	 * Test clear() method by ensuring that the Pile is cleared
	 */
	private static void clearTest() {

		Pile testPile = new Pile();

		Card nine = new Card(Rank.NINE, Suit.SPADES);

		testPile.addCard(nine);

		Card ace = new Card(Rank.ACE, Suit.CLUBS);

		testPile.addCard(ace);

		Card seven = new Card(Rank.SEVEN, Suit.SPADES);

		testPile.addCard(seven);

		Card queen = new Card(Rank.QUEEN, Suit.SPADES);

		testPile.addCard(queen);

		Card ten = new Card(Rank.TEN, Suit.SPADES);

		testPile.addCard(ten);

		Card four = new Card(Rank.FOUR, Suit.HEARTS);

		testPile.addCard(four);

		assertTrue(testPile.getSize() == 6);

		testPile.clear();

		assertTrue(testPile.getSize() == 0);

	}

	/**
	 * Tests toArray() method by ensuring that the expected array is returned
	 */
	private static void toArrayTest() {

		Card[] expectedCardArray = new Card[6];

		Pile testPile = new Pile();

		Card nine = new Card(Rank.NINE, Suit.SPADES);

		testPile.addCard(nine);

		expectedCardArray[0] = nine;

		Card ace = new Card(Rank.ACE, Suit.CLUBS);

		testPile.addCard(ace);

		expectedCardArray[1] = ace;

		Card seven = new Card(Rank.SEVEN, Suit.SPADES);

		testPile.addCard(seven);

		expectedCardArray[2] = seven;

		Card queen = new Card(Rank.QUEEN, Suit.SPADES);

		testPile.addCard(queen);

		expectedCardArray[3] = queen;

		Card ten = new Card(Rank.TEN, Suit.SPADES);

		testPile.addCard(ten);

		expectedCardArray[4] = ten;

		Card four = new Card(Rank.FOUR, Suit.HEARTS);

		testPile.addCard(four);

		expectedCardArray[5] = four;

		Card[] actualCardArray = testPile.toArray();

		for (int i = 0; i < 6; i++) {
			assertTrue(actualCardArray[i] == expectedCardArray[i]);
		}

	}

	/**
	 * Tests toString() method by ensuring that the expected String is returned
	 */
	private static void toStringTest() {

		Pile testPile = new Pile();

		Card nine = new Card(Rank.NINE, Suit.SPADES);

		testPile.addCard(nine);

		Card ace = new Card(Rank.ACE, Suit.CLUBS);

		testPile.addCard(ace);

		Card seven = new Card(Rank.SEVEN, Suit.SPADES);

		testPile.addCard(seven);

		Card queen = new Card(Rank.QUEEN, Suit.SPADES);

		testPile.addCard(queen);

		Card ten = new Card(Rank.TEN, Suit.SPADES);

		testPile.addCard(ten);

		Card four = new Card(Rank.FOUR, Suit.HEARTS);

		testPile.addCard(four);

		String actualString = testPile.toString();

		String expectedString = "9 ♠\nA ♣\n7 ♠\nQ ♠\n10 ♠\n4 ♥\n";

		assertTrue(actualString.equals(expectedString));

	}

} // end class Pile
