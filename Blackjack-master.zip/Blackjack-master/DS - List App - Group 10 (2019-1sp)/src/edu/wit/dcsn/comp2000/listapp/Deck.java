/*
 * Dave Rosenberg
 * Brody Nagy
 * Matt Champan
 * Group 10
 * Blackjack
 * Comp 2000 - Data Structures
 * Lab: List application - card game
 * Spring, 2019
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your
 * learning for this course. You may not use this code for any other
 * assignments, in my course or elsewhere, without explicit permission, in
 * advance, from myself (and the instructor of any other course).
 * 
 * Further, you may not post or otherwise share this code with anyone other than
 * current students in my sections of this course. Violation of these usage
 * restrictions will be considered a violation of the Wentworth Institute of
 * Technology Academic Honesty Policy.
 */

package edu.wit.dcsn.comp2000.listapp;

import static org.junit.Assert.assertTrue;

/**
 * A specific Pile of Cards that can deal Cards to Players
 * 
 * @author David Rosenberg
 * @author Brody Nagy
 * @author Matt Chapman
 *
 */
public class Deck extends Pile {

	/**
	 * Construct a Deck
	 */
	public Deck() {

		super();

		// create a card for each suit and rank-- 52 cards total
		for (Suit aSuit : Suit.values()) {
			for (Rank aRank : Rank.values()) {
				this.addCard(new Card(aRank, aSuit));
			}
		}

		// shuffle the deck
		this.shuffle();
	}
	// end constructor

	/**
	 * Construct special Decks with different properties (used for testing)
	 * 
	 * @param i
	 */
	public Deck(int i) {

		super();

		if (i == 1) {

			Card card = new Card(Rank.SEVEN, Suit.CLUBS);

			this.addCard(card);

			card = new Card(Rank.TEN, Suit.CLUBS);

			this.addCard(card);

			card = new Card(Rank.TEN, Suit.SPADES);

			this.addCard(card);

			card = new Card(Rank.SEVEN, Suit.SPADES);

			this.addCard(card);

			card = new Card(Rank.TWO, Suit.SPADES);

			this.addCard(card);

		}

		else if (i == 2) {

			Card card = new Card(Rank.ACE, Suit.CLUBS);

			this.addCard(card);

			card = new Card(Rank.TWO, Suit.SPADES);

			this.addCard(card);

			card = new Card(Rank.ACE, Suit.SPADES);

			this.addCard(card);

			card = new Card(Rank.TWO, Suit.CLUBS);

			this.addCard(card);

			card = new Card(Rank.ACE, Suit.DIAMONDS);

			this.addCard(card);

			card = new Card(Rank.ACE, Suit.HEARTS);

			this.addCard(card);

			card = new Card(Rank.TEN, Suit.HEARTS);

			this.addCard(card);

			card = new Card(Rank.SEVEN, Suit.DIAMONDS);

			this.addCard(card);

			card = new Card(Rank.TEN, Suit.DIAMONDS);

			this.addCard(card);

			card = new Card(Rank.SEVEN, Suit.HEARTS);

			this.addCard(card);

		}

		else if (i == 3) {

			Card card = new Card(Rank.ACE, Suit.CLUBS);

			this.addCard(card);

			card = new Card(Rank.NINE, Suit.SPADES);

			this.addCard(card);

			card = new Card(Rank.NINE, Suit.CLUBS);

			this.addCard(card);

			card = new Card(Rank.ACE, Suit.SPADES);

			this.addCard(card);
		}

		else if (i == 4) {

			Card card = new Card(Rank.NINE, Suit.SPADES);

			this.addCard(card);

			card = new Card(Rank.ACE, Suit.CLUBS);

			this.addCard(card);

			card = new Card(Rank.SEVEN, Suit.SPADES);

			this.addCard(card);

			card = new Card(Rank.QUEEN, Suit.SPADES);

			this.addCard(card);

			card = new Card(Rank.TEN, Suit.SPADES);

			this.addCard(card);

			card = new Card(Rank.FOUR, Suit.HEARTS);

			this.addCard(card);
		}

	}

	/**
	 * removes the top card from the deck and returns it- deals a card
	 * 
	 * @return
	 */
	public Card deal() {
		Card topCard = this.removeCard(0);
		return topCard;
	}

	/**
	 * Test driver for Deck, tests are in alphabetical order
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		constructorTest();
		dealTest();

	} // end main()

	/**
	 * Method to test deal() method and custom constructor
	 */
	private static void dealTest() {
		Deck testDeck = new Deck(3);
		Card testAce = new Card(Rank.ACE, Suit.CLUBS);
		assertTrue(testAce.compareTo(testDeck.deal()) == 0);

	}

	/**
	 * Method to test Deck default constructor and superclass shuffle method
	 */
	private static void constructorTest() {

		Deck testDeck = new Deck();

		// create a card for each suit and rank-- 52 cards total
		for (Suit aSuit : Suit.values()) {
			for (Rank aRank : Rank.values()) {
				testDeck.addCard(new Card(aRank, aSuit));
			}
		}

		String deck = testDeck.toString();

		testDeck.shuffle();

		String shufled = testDeck.toString();

		assertTrue(!shufled.equals(deck));

	}

} // end class Deck
