/*
 * Group 10
 * Brody Nagy
 * Matt Champan
 * Comp 2000 - Data Structures
 * Lab: List application - card game
 * Spring, 2019
 */

package edu.wit.dcsn.comp2000.listapp;

import edu.wit.dcsn.comp2000.listapp.Player;

import static org.junit.Assert.assertTrue;

import edu.wit.dcsn.comp2000.listapp.Deck;
import edu.wit.dcsn.comp2000.listapp.Hand;

/**
 * A subclass of Player to represent the Dealer
 * 
 * @author Brody Nagy
 * @author Matt Chapman
 *
 */
public class Dealer extends Player {

	/**
	 * Dealer constructor
	 */
	public Dealer() {
		super("Dealer");
		this.chips = 2000000; // give the dealer plenty of chips

	}

	/**
	 * calls Hands dealerHandToString() method to return a string of dealers visible
	 * cards
	 * 
	 * @return string of cards in visible hand
	 */
	public String dealerHand() {
		return this.hand.dealerHandToString();
	}

	@Override
	public void resetPlayer() {
		this.hand.clear();
		this.bust = false;
		this.chips = 2000000;
		this.blackjack = false;
	}

	/**
	 * 
	 * Test driver for Dealer, tests are in alphabetical order
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		constructorTest();
		dealerHandTest();
		resetTest();
	}

	/**
	 * Tests Dealer constructor method
	 */
	private static void constructorTest() {
		Player.resetID();
		Dealer testDealer = new Dealer();

		assertTrue(testDealer.getName().equals("Dealer"));
		assertTrue(testDealer.chipCount() == 2000000);

	}

	/**
	 * Tests dealerHand() method
	 */
	private static void dealerHandTest() {

		Player.resetID();
		Dealer testDealer = new Dealer();

		Card seven = new Card(Rank.SEVEN, Suit.CLUBS);
		Card ace = new Card(Rank.ACE, Suit.CLUBS);

		testDealer.addCard(ace);
		testDealer.addCard(seven);

		String expected = "|⚓| |7♣|\nMax Sum: 18";

		String actual = testDealer.dealerHand();

		assertTrue(expected.equals(actual));
	}

	/**
	 * Tests Dealer reset() method
	 */
	private static void resetTest() {

		Player.resetID();
		Dealer testDealer = new Dealer();

		Card seven = new Card(Rank.SEVEN, Suit.CLUBS);
		Card ace = new Card(Rank.ACE, Suit.CLUBS);

		testDealer.addCard(ace);
		testDealer.addCard(seven);

		testDealer.setBust(true);

		testDealer.setBlackjack();

		testDealer.recieveChips(5000);

		assertTrue(testDealer.handTotal() == 18);
		assertTrue(testDealer.getBust());
		assertTrue(testDealer.hasBlackjack());
		assertTrue(testDealer.chipCount() == 2000000 + 5000);

		testDealer.resetPlayer();

		assertTrue(testDealer.handTotal() == 0);
		assertTrue(!testDealer.getBust());
		assertTrue(!testDealer.hasBlackjack());
		assertTrue(testDealer.chipCount() == 2000000);

	}

}
