/*
 * Dave Rosenberg
 * Brody Nagy
 * Matt Champan
 * Group 10
 * Comp 2000 - Data Structures
 * Lab: List application - card game
 * Spring, 2019
 * 
 * Usage restrictions:
 * 
 * You may use this code for exploration, experimentation, and furthering your
 * learning for this course. You may not use this code for any other
 * assignments, in my course or elsewhere, without explicit permission, in
 * advance, from myself (and the instructor of any other course).
 * 
 * Further, you may not post or otherwise share this code with anyone other than
 * current students in my sections of this course. Violation of these usage
 * restrictions will be considered a violation of the Wentworth Institute of
 * Technology Academic Honesty Policy.
 */

package edu.wit.dcsn.comp2000.listapp;

import static org.junit.Assert.assertTrue;

/**
 * Comparable object with suit and rank used to represent a playing Card
 * 
 * @author David Rosenberg
 * @author Brody Nagy
 * @author Matt Chapman
 *
 */
public class Card implements Comparable<Card> {
	final Rank rank;
	final Suit suit;

	/**
	 * Card constructor
	 * 
	 * @param rank specifies rank of card to create
	 * @param suit specifies suit of card to create
	 */
	public Card(Rank rank, Suit suit) {

		this.rank = rank;
		this.suit = suit;

	} // end constructor

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(Card compareCard) {

		return (compareCard.getRank().getAltPoints() - this.getRank().getAltPoints());

	} // end compareTo()

	/**
	 * Accessor for card rank
	 * 
	 * @return rank of card
	 */
	public Rank getRank() {
		return this.rank;
	}

	/**
	 * Accessor for card suit
	 * 
	 * @return suit of card
	 */
	public Suit getSuit() {
		return this.suit;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		return rank.getGraphic() + suit.getGraphic(); // return rank and suit graphics

	} // end toString()

	/**
	 * Test driver for Card class, tests are in alphabetical order
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		compareCardTest();
		createCardTest();
		createDeckTest();

	} // end main()

	/**
	 * Create a card with a specified rank and suit, and assert that the card's rank
	 * is specified rank and the card's suit is the specified suit test constructor,
	 * compareTo(), getRank(), and getSuit()
	 */
	private static void createCardTest() {

		// create an ace of spades
		Card aceSpades = new Card(Rank.ACE, Suit.SPADES);

		// assert that the rank of the ace of spades is 'ace'
		assertTrue(aceSpades.getRank() == Rank.ACE);

		// assert that the suit of the ace of spades is 'spades'
		assertTrue(aceSpades.getSuit() == Suit.SPADES);

	}

	/**
	 * Creates a card for each rank of each suit, asserts that the string of all
	 * created cards is equal to the expected string tests constructor
	 */
	private static void createDeckTest() {

		// string to hold string of all 52 cards
		String deckString = "";

		// expected string of deck
		String expectedDeckString = "A♣2♣3♣4♣5♣6♣7♣8♣9♣10♣J♣Q♣K♣A♦2♦3♦4♦5♦6♦7♦8♦9♦10♦J♦Q♦K♦A♥2♥3♥4♥5♥6♥7♥8♥9♥10♥J♥Q♥K♥A♠2♠3♠4♠5♠6♠7♠8♠9♠10♠J♠Q♠K♠";

		// card to hold each newly created card
		Card testCard = new Card(Rank.ACE, Suit.CLUBS);

		// track each card created
		int cardsCreated = 0;

		// make a card for each suit and rank
		for (Suit aSuit : Suit.values()) {
			for (Rank aRank : Rank.values()) {
				testCard = new Card(aRank, aSuit);
				deckString += testCard.toString();
				cardsCreated++;
			}
		}

		// assert that 52 cards were created
		assertTrue(cardsCreated == 52);

		// assert that the deck created equals the expected deck
		assertTrue(deckString.equals(expectedDeckString));

	}

	/**
	 * Creates cards of different ranks and asserts that compareTo() returns the
	 * expected value, tests compareTo() method
	 */
	private static void compareCardTest() {

		// create an ace of clubs
		Card aceClubs = new Card(Rank.ACE, Suit.CLUBS);

		// create an ace of spades
		Card aceSpades = new Card(Rank.ACE, Suit.SPADES);

		// assert that the rank of the ace of spades is 'ace'
		assertTrue(aceSpades.getRank() == Rank.ACE);

		// assert that the suit of the ace of spades is 'spades'
		assertTrue(aceSpades.getSuit() == Suit.SPADES);

		// assert that the aces are equal
		assertTrue(aceClubs.compareTo(aceSpades) == 0);

		// create a two of clubs
		Card twoClubs = new Card(Rank.TWO, Suit.CLUBS);

		// create an three of clubs
		Card threeClubs = new Card(Rank.THREE, Suit.CLUBS);

		// assert that the two is smaller than the ace
		assertTrue(aceClubs.compareTo(twoClubs) < 0);

		// assert that the three is larger than the two
		assertTrue(twoClubs.compareTo(threeClubs) > 0);

	}

} // end class Card
